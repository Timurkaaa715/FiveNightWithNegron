#!/usr/bin/env bash
# Downloads SDL2 into the Android project (needs git + internet, run once).
set -euo pipefail
cd "$(dirname "$0")"
SDL_TAG="release-2.30.9"
if [ ! -d app/jni/SDL ]; then
  git clone --depth 1 --branch "$SDL_TAG" https://github.com/libsdl-org/SDL.git app/jni/SDL
fi
mkdir -p app/src/main/java-sdl
cp -r app/jni/SDL/android-project/app/src/main/java/org app/src/main/java-sdl/
echo "SDL2 ready. Now run: gradle assembleRelease   (or open android/ in Android Studio)"
