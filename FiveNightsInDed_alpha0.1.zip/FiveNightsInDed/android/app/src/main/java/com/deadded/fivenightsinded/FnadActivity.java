package com.deadded.fivenightsinded;

import org.libsdl.app.SDLActivity;

/** Entry point: SDL loads libSDL2.so + libmain.so and calls main() in sdl_main.cpp. */
public class FnadActivity extends SDLActivity {
    @Override
    protected String[] getLibraries() {
        return new String[] { "SDL2", "main" };
    }
}
