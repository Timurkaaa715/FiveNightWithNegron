#pragma once
#include <mutex>
#include <vector>

// All sounds in the alpha are synthesised at start-up (no audio files yet).
enum class Sfx {
    Hum,          // office fan / fluorescent hum (loop)
    Static,       // camera static (loop)
    CamBlip,      // switching cameras
    MonitorUp,    // opening the camera tablet
    DoorClose,
    DoorOpen,
    LightBuzz,    // door light (loop)
    Footstep,
    CanOpen,      // "pssht" — beer delivered
    Glug,         // drinking
    Burp,         // Negron's signature cue
    CouchCreak,   // he gets up from the couch
    DoorBang,     // banging on the closed door
    Scream,       // jumpscare
    Chime,        // 6 AM
    PowerDown,
    TvCrowd,      // football crowd on the TV (loop)
    FridgeHum,    // kitchen fridge (loop)
    LogoSting,    // studio logo sound
    Click,        // UI
    Count
};

class Audio {
public:
    static constexpr int RATE = 22050;

    void init();
    // Returns a voice handle (or -1). Volume 0..1, pan -1..1.
    int play(Sfx s, float volume = 1.0f, float pan = 0.0f, bool loop = false, float pitch = 1.0f);
    void stop(int handle);
    void setVolume(int handle, float volume);
    void stopAll();
    // Mixes interleaved stereo float samples. Thread-safe (audio thread).
    void mix(float* out, int frames);
    void setMasterVolume(float v) { master_ = v; }

private:
    struct Voice {
        int sfx = -1;
        double pos = 0;
        float vol = 1, pan = 0, pitch = 1;
        bool loop = false;
        int id = 0;
    };
    std::vector<std::vector<float>> sounds_;
    std::vector<Voice> voices_;
    std::mutex mtx_;
    int nextId_ = 1;
    float master_ = 0.9f;
};
