#include "Textures.h"

namespace {

Texture make(int w, int h) {
    Texture t;
    t.w = w; t.h = h;
    t.px.assign(w * h, Vec3(1, 1, 1));
    return t;
}

float hashNoise(int x, int y, uint32_t seed) {
    uint32_t h = uint32_t(x) * 374761393u + uint32_t(y) * 668265263u + seed * 2246822519u;
    h = (h ^ (h >> 13)) * 1274126177u;
    return ((h ^ (h >> 16)) & 0xFFFF) / 65535.0f;
}

float valueNoise(float x, float y, int period, uint32_t seed) {
    int x0 = int(std::floor(x)), y0 = int(std::floor(y));
    float fx = x - x0, fy = y - y0;
    auto h = [&](int a, int b) { return hashNoise(((a % period) + period) % period, ((b % period) + period) % period, seed); };
    float a = lerpf(h(x0, y0), h(x0 + 1, y0), smooth01(fx));
    float b = lerpf(h(x0, y0 + 1), h(x0 + 1, y0 + 1), smooth01(fx));
    return lerpf(a, b, smooth01(fy));
}

}  // namespace

TextureSet generateTextures(Renderer& r) {
    TextureSet ts;
    const int N = 64;

    {  // wallpaper: vertical stripes + diamond pattern + stains
        Texture t = make(N, N);
        for (int y = 0; y < N; ++y)
            for (int x = 0; x < N; ++x) {
                Vec3 base = rgb(150, 132, 96);
                if ((x % 16) < 2) base = rgb(120, 100, 70);
                int dx = std::abs((x % 16) - 8), dy = std::abs((y % 16) - 8);
                if (dx + dy == 5) base = rgb(170, 150, 110);
                float stain = valueNoise(x / 12.0f, y / 12.0f, 6, 11);
                base = base * (0.75f + 0.25f * stain) * (0.95f + 0.05f * hashNoise(x, y, 3));
                t.px[y * N + x] = base;
            }
        ts.wallpaper = r.addTexture(t);
    }
    {  // linoleum checker
        Texture t = make(N, N);
        for (int y = 0; y < N; ++y)
            for (int x = 0; x < N; ++x) {
                bool c = ((x / 16) + (y / 16)) & 1;
                Vec3 b = c ? rgb(110, 90, 70) : rgb(160, 140, 110);
                b = b * (0.85f + 0.15f * valueNoise(x / 8.0f, y / 8.0f, 8, 5));
                t.px[y * N + x] = b;
            }
        ts.linoleum = r.addTexture(t);
    }
    {  // wood planks
        Texture t = make(N, N);
        for (int y = 0; y < N; ++y)
            for (int x = 0; x < N; ++x) {
                int plank = x / 16;
                float grain = std::sin((y + plank * 13) * 0.4f + valueNoise(x / 4.0f, y / 16.0f, 16, plank) * 4.0f);
                Vec3 b = rgb(120, 72, 38) * (0.8f + 0.12f * grain + 0.08f * hashNoise(plank, 0, 9));
                if (x % 16 == 0) b = b * 0.55f;
                t.px[y * N + x] = b;
            }
        ts.wood = r.addTexture(t);
    }
    {  // fabric: woven
        Texture t = make(N, N);
        for (int y = 0; y < N; ++y)
            for (int x = 0; x < N; ++x) {
                float w = ((x + y) % 4 < 2) ? 1.0f : 0.85f;
                float worn = valueNoise(x / 10.0f, y / 10.0f, 6, 21);
                t.px[y * N + x] = rgb(140, 90, 60) * w * (0.75f + 0.3f * worn);
            }
        ts.fabric = r.addTexture(t);
    }
    {  // kitchen tiles
        Texture t = make(N, N);
        for (int y = 0; y < N; ++y)
            for (int x = 0; x < N; ++x) {
                bool grout = (x % 16 == 0) || (y % 16 == 0);
                Vec3 b = grout ? rgb(90, 90, 80) : rgb(200, 210, 200);
                if (!grout && hashNoise(x / 16, y / 16, 4) > 0.8f) b = rgb(120, 170, 160);
                b = b * (0.9f + 0.1f * valueNoise(x / 6.0f, y / 6.0f, 10, 8));
                t.px[y * N + x] = b;
            }
        ts.tiles = r.addTexture(t);
    }
    {  // wall carpet: red with ornamental diamonds
        Texture t = make(N, N);
        for (int y = 0; y < N; ++y)
            for (int x = 0; x < N; ++x) {
                int cx = std::abs(x - 32), cy = std::abs(y - 32);
                int d = cx + cy;
                Vec3 b = rgb(140, 20, 25);
                if (d % 10 < 2) b = rgb(220, 170, 60);
                else if (d % 10 < 4) b = rgb(30, 20, 60);
                if (x < 3 || y < 3 || x > 60 || y > 60) b = rgb(30, 20, 20);
                int sx = x % 16, sy = y % 16;
                if (std::abs(sx - 8) + std::abs(sy - 8) < 3 && d > 26) b = rgb(230, 220, 190);
                b = b * (0.85f + 0.15f * hashNoise(x, y, 77));
                t.px[y * N + x] = b;
            }
        ts.carpet = r.addTexture(t);
    }
    {  // metal shutter
        Texture t = make(N, N);
        for (int y = 0; y < N; ++y)
            for (int x = 0; x < N; ++x) {
                float rib = (y % 8 < 2) ? 0.6f : (y % 8 < 4 ? 1.1f : 0.9f);
                float rust = valueNoise(x / 9.0f, y / 9.0f, 7, 31);
                Vec3 b = rgb(120, 125, 130) * rib;
                b = lerp(b, rgb(110, 60, 30), clampf((rust - 0.6f) * 2.5f, 0, 1));
                if ((x % 32 == 4 || x % 32 == 28) && (y % 8 == 5)) b = rgb(60, 60, 60);
                t.px[y * N + x] = b;
            }
        ts.metal = r.addTexture(t);
    }
    {  // concrete
        Texture t = make(N, N);
        for (int y = 0; y < N; ++y)
            for (int x = 0; x < N; ++x) {
                float n = valueNoise(x / 6.0f, y / 6.0f, 10, 41) * 0.6f + hashNoise(x, y, 2) * 0.4f;
                Vec3 b = rgb(105, 110, 100) * (0.7f + 0.35f * n);
                if (y % 32 == 0) b = b * 0.7f;
                t.px[y * N + x] = b;
            }
        ts.concrete = r.addTexture(t);
    }
    {  // night city: sky gradient + panel building with lit windows
        Texture t = make(N, N);
        for (int y = 0; y < N; ++y)
            for (int x = 0; x < N; ++x) {
                Vec3 sky = lerp(rgb(10, 14, 40), rgb(50, 60, 110), y / 64.0f);
                Vec3 b = sky;
                bool building = y > 14 && x > 4 && x < 58;
                if (building) {
                    b = rgb(40, 34, 36);
                    int wx = (x - 6) % 6, wy = (y - 16) % 7;
                    if (wx < 3 && wy < 3 && x < 56) {
                        float lit = hashNoise((x - 6) / 6, (y - 16) / 7, 99);
                        b = lit > 0.72f ? rgb(255, 200, 110) : rgb(25, 25, 35);
                    }
                }
                if (y < 14 && hashNoise(x, y, 5) > 0.985f) b = rgb(200, 200, 230);
                t.px[y * N + x] = b;
            }
        ts.cityNight = r.addTexture(t);
    }
    {  // TV football
        Texture t = make(N, N);
        for (int y = 0; y < N; ++y)
            for (int x = 0; x < N; ++x) {
                Vec3 b = ((x / 8) & 1) ? rgb(40, 140, 50) : rgb(50, 160, 60);
                if (x == 32 || y == 4 || y == 59 || x == 2 || x == 61) b = rgb(230, 230, 230);
                int dx = x - 32, dy = y - 32;
                if (std::abs(dx * dx + dy * dy - 100) < 12) b = rgb(230, 230, 230);
                if (hashNoise(x / 3, y / 3, 13) > 0.97f) b = (hashNoise(x, y, 14) > 0.5f) ? rgb(220, 30, 30) : rgb(30, 60, 220);
                if (y < 8 && x > 40) b = rgb(20, 20, 20);  // score board
                if (y < 8 && x > 42 && x < 60 && y > 1 && y < 7 && hashNoise(x, y, 8) > 0.5f) b = rgb(255, 255, 255);
                t.px[y * N + x] = b;
            }
        ts.tvFootball = r.addTexture(t);
    }
    {  // beer label: golden with red band
        Texture t = make(N, N);
        for (int y = 0; y < N; ++y)
            for (int x = 0; x < N; ++x) {
                Vec3 b = rgb(220, 170, 40);
                if (y > 24 && y < 40) b = rgb(170, 20, 20);
                if (y > 28 && y < 36 && (x % 8) < 5) b = rgb(250, 240, 220);
                if (y < 4 || y > 60) b = rgb(190, 190, 190);
                t.px[y * N + x] = b;
            }
        ts.beerLabel = r.addTexture(t);
    }
    {  // poster: skull + "DD"
        Texture t = make(N, N);
        for (int y = 0; y < N; ++y)
            for (int x = 0; x < N; ++x) {
                Vec3 b = rgb(30, 10, 10);
                int dx = x - 32, dy = y - 26;
                if (dx * dx + dy * dy < 220) b = rgb(220, 210, 190);
                if ((dx + 7) * (dx + 7) + (dy + 1) * (dy + 1) < 18 || (dx - 7) * (dx - 7) + (dy + 1) * (dy + 1) < 18) b = rgb(20, 0, 0);
                if (y > 38 && y < 46 && std::abs(dx) < 10 && (x % 3) != 0) b = rgb(220, 210, 190);
                if (y > 46 && y < 58 && std::abs(dx) < 14 && ((y + x / 2) % 3 == 0)) b = rgb(200, 200, 200);  // beard
                if (y > 52 && y < 62 && (x < 8 || x > 56)) b = rgb(180, 20, 20);
                t.px[y * N + x] = b * (0.85f + 0.15f * hashNoise(x, y, 61));
            }
        ts.poster = r.addTexture(t);
    }
    {  // ceiling tiles
        Texture t = make(N, N);
        for (int y = 0; y < N; ++y)
            for (int x = 0; x < N; ++x) {
                bool frame = (x % 32 < 2) || (y % 32 < 2);
                Vec3 b = frame ? rgb(80, 80, 80) : rgb(170, 165, 150);
                b = b * (0.85f + 0.15f * hashNoise(x, y, 17)) * (0.8f + 0.2f * valueNoise(x / 10.0f, y / 10.0f, 6, 18));
                t.px[y * N + x] = b;
            }
        ts.ceiling = r.addTexture(t);
    }
    return ts;
}
