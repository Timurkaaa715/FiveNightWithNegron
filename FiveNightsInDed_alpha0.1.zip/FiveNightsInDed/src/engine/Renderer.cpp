#include "Renderer.h"
#include "FontData.h"
#include <unordered_map>
#include <cstring>

std::vector<uint32_t> utf8Decode(const std::string& s) {
    std::vector<uint32_t> out;
    for (size_t i = 0; i < s.size();) {
        unsigned char c = s[i];
        uint32_t cp = '?';
        int len = 1;
        if (c < 0x80) { cp = c; }
        else if ((c >> 5) == 6 && i + 1 < s.size()) { cp = ((c & 0x1F) << 6) | (s[i + 1] & 0x3F); len = 2; }
        else if ((c >> 4) == 14 && i + 2 < s.size()) { cp = ((c & 0x0F) << 12) | ((s[i + 1] & 0x3F) << 6) | (s[i + 2] & 0x3F); len = 3; }
        else if ((c >> 3) == 30 && i + 3 < s.size()) { cp = '?'; len = 4; }
        out.push_back(cp);
        i += len;
    }
    return out;
}

static int glyphIndex(uint32_t cp) {
    static std::unordered_map<uint32_t, int> map;
    if (map.empty())
        for (int i = 0; i < font_data::GLYPH_COUNT; ++i) map[font_data::CODEPOINTS[i]] = i;
    auto it = map.find(cp);
    if (it != map.end()) return it->second;
    it = map.find('?');
    return it->second;
}

Renderer::Renderer() : color_(W * H), depth_(W * H, 0.0f) {}

int Renderer::addTexture(Texture t) {
    textures_.push_back(std::move(t));
    return int(textures_.size()) - 1;
}

void Renderer::clear(Vec3 col) {
    std::fill(color_.begin(), color_.end(), col);
    std::fill(depth_.begin(), depth_.end(), 0.0f);
}

void Renderer::setCamera(const Vec3& eye, const Vec3& target, float fovDeg, float roll) {
    eye_ = eye;
    Vec3 up(std::sin(roll), std::cos(roll), 0);
    view_ = Mat4::lookAt(eye, target, up);
    proj_ = Mat4::perspective(fovDeg * PI / 180.0f, float(W) / H, 0.05f, 60.0f);
    viewProj_ = proj_ * view_;
}

void Renderer::setEnvironment(Vec3 ambient, const std::vector<Light>& lights, Vec3 fogColor, float fogNear, float fogFar) {
    ambient_ = ambient;
    lights_ = lights;
    fogColor_ = fogColor;
    fogNear_ = fogNear;
    fogFar_ = fogFar;
}

void Renderer::drawMesh(const Mesh& mesh, const Mat4& model) {
    Mat4 mvp = viewProj_ * model;
    for (const Tri& t : mesh.tris) {
        ClipVert cv[3];
        for (int i = 0; i < 3; ++i) {
            const Vertex& v = t.v[i];
            Vec3 wp = model.point(v.p);
            Vec3 lit(1, 1, 1);
            if (!t.emissive) {
                Vec3 n = normalize(model.dir(v.n));
                lit = ambient_;
                for (const Light& L : lights_) {
                    Vec3 d = L.pos - wp;
                    float dist = length(d);
                    if (dist >= L.radius) continue;
                    float nd = dot(n, d * (1.0f / (dist + 1e-5f)));
                    if (nd <= 0) continue;
                    float att = 1.0f - dist / L.radius;
                    att *= att;
                    lit += L.color * (nd * att);
                }
            }
            cv[i].clip = mvp * Vec4(v.p.x, v.p.y, v.p.z, 1);
            cv[i].col = v.c * lit;
            cv[i].uv = v.uv;
            float dist = cv[i].clip.w;
            cv[i].fog = t.emissive ? clampf((dist - fogNear_) / (fogFar_ - fogNear_), 0, 1) * 0.5f
                                   : clampf((dist - fogNear_) / (fogFar_ - fogNear_), 0, 1);
        }
        clipAndDraw(cv, t.tex, mesh.cull);
    }
}

void Renderer::clipAndDraw(ClipVert v[3], int tex, bool cull) {
    const float NEAR_W = 0.05f;
    auto inside = [&](const ClipVert& c) { return c.clip.w > NEAR_W; };
    bool allIn = inside(v[0]) && inside(v[1]) && inside(v[2]);
    if (allIn) { rasterTri(v[0], v[1], v[2], tex, cull); return; }
    if (!inside(v[0]) && !inside(v[1]) && !inside(v[2])) return;

    ClipVert out[4];
    int n = 0;
    for (int i = 0; i < 3; ++i) {
        const ClipVert& a = v[i];
        const ClipVert& b = v[(i + 1) % 3];
        bool ia = inside(a), ib = inside(b);
        if (ia) out[n++] = a;
        if (ia != ib) {
            float t = (NEAR_W - a.clip.w) / (b.clip.w - a.clip.w);
            ClipVert c;
            c.clip = Vec4(lerpf(a.clip.x, b.clip.x, t), lerpf(a.clip.y, b.clip.y, t), lerpf(a.clip.z, b.clip.z, t), NEAR_W);
            c.col = lerp(a.col, b.col, t);
            c.uv = Vec2(lerpf(a.uv.x, b.uv.x, t), lerpf(a.uv.y, b.uv.y, t));
            c.fog = lerpf(a.fog, b.fog, t);
            out[n++] = c;
        }
    }
    for (int i = 1; i + 1 < n; ++i) rasterTri(out[0], out[i], out[i + 1], tex, cull);
}

void Renderer::rasterTri(const ClipVert& a, const ClipVert& b, const ClipVert& c, int tex, bool cull) {
    struct S { float x, y, iw; };
    auto toScreen = [](const ClipVert& v) {
        float iw = 1.0f / v.clip.w;
        return S{(v.clip.x * iw * 0.5f + 0.5f) * W, (0.5f - v.clip.y * iw * 0.5f) * H, iw};
    };
    S s0 = toScreen(a), s1 = toScreen(b), s2 = toScreen(c);
    float area = (s1.x - s0.x) * (s2.y - s0.y) - (s1.y - s0.y) * (s2.x - s0.x);
    if (std::fabs(area) < 1e-6f) return;
    if (cull && area >= 0) return;  // CCW (y-up) faces are front facing -> negative in y-down

    int minX = std::max(0, int(std::floor(std::min({s0.x, s1.x, s2.x}))));
    int maxX = std::min(W - 1, int(std::ceil(std::max({s0.x, s1.x, s2.x}))));
    int minY = std::max(0, int(std::floor(std::min({s0.y, s1.y, s2.y}))));
    int maxY = std::min(H - 1, int(std::ceil(std::max({s0.y, s1.y, s2.y}))));
    if (minX > maxX || minY > maxY) return;

    float invArea = 1.0f / area;
    const Texture* T = (tex >= 0 && tex < int(textures_.size())) ? &textures_[tex] : nullptr;

    // attributes pre-divided by w
    float iw0 = s0.iw, iw1 = s1.iw, iw2 = s2.iw;
    Vec3 c0 = a.col * iw0, c1 = b.col * iw1, c2 = c.col * iw2;
    float u0 = a.uv.x * iw0, u1 = b.uv.x * iw1, u2 = c.uv.x * iw2;
    float v0 = a.uv.y * iw0, v1 = b.uv.y * iw1, v2 = c.uv.y * iw2;
    float f0 = a.fog * iw0, f1 = b.fog * iw1, f2 = c.fog * iw2;

    for (int y = minY; y <= maxY; ++y) {
        float py = y + 0.5f;
        for (int x = minX; x <= maxX; ++x) {
            float px = x + 0.5f;
            float w0 = ((s1.x - px) * (s2.y - py) - (s1.y - py) * (s2.x - px)) * invArea;
            float w1 = ((s2.x - px) * (s0.y - py) - (s2.y - py) * (s0.x - px)) * invArea;
            float w2 = 1.0f - w0 - w1;
            if (w0 < 0 || w1 < 0 || w2 < 0) continue;
            float iw = w0 * iw0 + w1 * iw1 + w2 * iw2;
            int idx = y * W + x;
            if (iw <= depth_[idx]) continue;
            depth_[idx] = iw;
            float rw = 1.0f / iw;
            Vec3 col = (c0 * w0 + c1 * w1 + c2 * w2) * rw;
            if (T) {
                float u = (u0 * w0 + u1 * w1 + u2 * w2) * rw;
                float v = (v0 * w0 + v1 * w1 + v2 * w2) * rw;
                col = col * T->sample(u, v);
            }
            float fog = clampf((f0 * w0 + f1 * w1 + f2 * w2) * rw, 0, 1);
            color_[idx] = lerp(col, fogColor_, fog);
        }
    }
}

// ---------------- 2D ----------------

void Renderer::rect(int x, int y, int w, int h, Vec3 col, float alpha) {
    int x0 = std::max(0, x), y0 = std::max(0, y);
    int x1 = std::min(W, x + w), y1 = std::min(H, y + h);
    for (int yy = y0; yy < y1; ++yy)
        for (int xx = x0; xx < x1; ++xx) {
            Vec3& p = color_[yy * W + xx];
            p = alpha >= 1.0f ? col : lerp(p, col, alpha);
        }
}

void Renderer::rectOutline(int x, int y, int w, int h, Vec3 col, int t) {
    rect(x, y, w, t, col);
    rect(x, y + h - t, w, t, col);
    rect(x, y, t, h, col);
    rect(x + w - t, y, t, h, col);
}

void Renderer::line(int x0, int y0, int x1, int y1, Vec3 col) {
    int dx = std::abs(x1 - x0), sx = x0 < x1 ? 1 : -1;
    int dy = -std::abs(y1 - y0), sy = y0 < y1 ? 1 : -1;
    int err = dx + dy;
    for (;;) {
        if (x0 >= 0 && x0 < W && y0 >= 0 && y0 < H) color_[y0 * W + x0] = col;
        if (x0 == x1 && y0 == y1) break;
        int e2 = 2 * err;
        if (e2 >= dy) { err += dy; x0 += sx; }
        if (e2 <= dx) { err += dx; y0 += sy; }
    }
}

int Renderer::textWidth(const std::string& s, int scale) const {
    return int(utf8Decode(s).size()) * font_data::GLYPH_W * scale;
}

void Renderer::text(int x, int y, const std::string& s, Vec3 col, int scale, bool shadow) {
    auto cps = utf8Decode(s);
    auto draw = [&](int ox, int oy, Vec3 c) {
        int cx = ox;
        for (uint32_t cp : cps) {
            const uint8_t* g = font_data::GLYPHS[glyphIndex(cp)];
            for (int gy = 0; gy < font_data::GLYPH_H; ++gy)
                for (int gx = 0; gx < font_data::GLYPH_W; ++gx)
                    if (g[gy] & (0x80 >> gx)) rect(cx + gx * scale, oy + gy * scale, scale, scale, c);
            cx += font_data::GLYPH_W * scale;
        }
    };
    if (shadow) draw(x + scale, y + scale, Vec3(0, 0, 0));
    draw(x, y, col);
}

void Renderer::textCentered(int cx, int y, const std::string& s, Vec3 col, int scale, bool shadow) {
    text(cx - textWidth(s, scale) / 2, y, s, col, scale, shadow);
}

// ---------------- post ----------------

void Renderer::noise(float amount, uint32_t seed) {
    Rng r(seed * 2654435761u + 7);
    for (auto& p : color_) {
        float n = (r.f01() - 0.5f) * amount;
        p = p + Vec3(n, n, n);
    }
}

void Renderer::scanlines(float s) {
    for (int y = 0; y < H; y += 2)
        for (int x = 0; x < W; ++x) color_[y * W + x] = color_[y * W + x] * (1.0f - s);
}

void Renderer::vignette(float s) {
    for (int y = 0; y < H; ++y)
        for (int x = 0; x < W; ++x) {
            float dx = (x - W * 0.5f) / (W * 0.5f), dy = (y - H * 0.5f) / (H * 0.5f);
            float d = clampf(1.0f - s * (dx * dx * 0.6f + dy * dy * 0.8f), 0, 1);
            color_[y * W + x] = color_[y * W + x] * d;
        }
}

void Renderer::tint(Vec3 mul, float desat) {
    for (auto& p : color_) {
        float l = p.x * 0.3f + p.y * 0.59f + p.z * 0.11f;
        p = lerp(p, Vec3(l, l, l), desat) * mul;
    }
}

void Renderer::brightness(float m) {
    for (auto& p : color_) p = p * m;
}

void Renderer::shake(int dx, int dy) {
    std::vector<Vec3> copy = color_;
    for (int y = 0; y < H; ++y)
        for (int x = 0; x < W; ++x) {
            int sx = std::clamp(x - dx, 0, W - 1), sy = std::clamp(y - dy, 0, H - 1);
            color_[y * W + x] = copy[sy * W + sx];
        }
}

void Renderer::blurDown() {
    std::vector<Vec3> copy = color_;
    for (int y = 1; y < H - 1; ++y)
        for (int x = 1; x < W - 1; ++x) {
            Vec3 s;
            for (int k = -1; k <= 1; ++k)
                for (int j = -1; j <= 1; ++j) s += copy[(y + k) * W + x + j];
            color_[y * W + x] = s * (1.0f / 9.0f);
        }
}

void Renderer::resolve(uint32_t* out) const {
    static const float bayer[4][4] = {{0, 8, 2, 10}, {12, 4, 14, 6}, {3, 11, 1, 9}, {15, 7, 13, 5}};
    for (int y = 0; y < H; ++y)
        for (int x = 0; x < W; ++x) {
            const Vec3& p = color_[y * W + x];
            float d = (bayer[y & 3][x & 3] + 0.5f) / 16.0f;
            auto q = [&](float v) {
                int c = int(clampf(v, 0, 1) * 31.0f + d);
                c = std::min(31, c);
                return uint32_t((c << 3) | (c >> 2));
            };
            uint32_t r = q(p.x), g = q(p.y), b = q(p.z);
            out[y * W + x] = 0xFF000000u | (b << 16) | (g << 8) | r;
        }
}
