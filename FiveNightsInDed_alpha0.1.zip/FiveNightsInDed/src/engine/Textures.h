#pragma once
#include "Renderer.h"

// Procedurally generated 64x64 textures (no image files needed in alpha).
struct TextureSet {
    int wallpaper = -1;    // faded soviet-style wallpaper with stains
    int linoleum = -1;     // checkered floor
    int wood = -1;         // parquet / furniture wood
    int fabric = -1;       // couch upholstery
    int tiles = -1;        // kitchen tiles
    int carpet = -1;       // the legendary wall carpet ("kovyor")
    int metal = -1;        // office door shutter
    int concrete = -1;     // office walls
    int cityNight = -1;    // panel building with lit windows
    int tvFootball = -1;   // football on the TV
    int beerLabel = -1;    // beer can label
    int poster = -1;       // "Dead Ded" poster in the office
    int ceiling = -1;
};

TextureSet generateTextures(Renderer& r);
