#pragma once
#include <cstdint>
#include <string>
#include <vector>
#include "Math.h"
#include "Mesh.h"

struct Texture {
    int w = 0, h = 0;          // must be powers of two
    std::vector<Vec3> px;
    Vec3 sample(float u, float v) const {
        int x = int(std::floor(u * w)) & (w - 1);
        int y = (h - 1) - (int(std::floor(v * h)) & (h - 1));  // v grows upward
        return px[y * w + x];
    }
};

struct Light {
    Vec3 pos;
    Vec3 color;
    float radius = 5.0f;
};

// Software rasteriser imitating the look of 6th-gen consoles (PS2):
// low internal resolution, Gouraud vertex lighting, distance fog,
// nearest-neighbour textures and a 16-bit ordered-dither output.
class Renderer {
public:
    static constexpr int W = 480;
    static constexpr int H = 270;

    Renderer();

    // --- textures ---
    int addTexture(Texture t);
    const Texture& texture(int id) const { return textures_[id]; }

    // --- 3D ---
    void clear(Vec3 col);
    void setCamera(const Vec3& eye, const Vec3& target, float fovDeg, float roll = 0.0f);
    void setEnvironment(Vec3 ambient, const std::vector<Light>& lights, Vec3 fogColor, float fogNear, float fogFar);
    void drawMesh(const Mesh& mesh, const Mat4& model = Mat4());

    // --- 2D (coordinates in framebuffer pixels) ---
    void rect(int x, int y, int w, int h, Vec3 col, float alpha = 1.0f);
    void rectOutline(int x, int y, int w, int h, Vec3 col, int thick = 1);
    void text(int x, int y, const std::string& utf8, Vec3 col, int scale = 1, bool shadow = true);
    int textWidth(const std::string& utf8, int scale = 1) const;
    void textCentered(int cx, int y, const std::string& utf8, Vec3 col, int scale = 1, bool shadow = true);
    void line(int x0, int y0, int x1, int y1, Vec3 col);

    // --- post effects ---
    void noise(float amount, uint32_t seed);
    void scanlines(float strength);
    void vignette(float strength);
    void tint(Vec3 mul, float desaturate);
    void brightness(float mul);
    void shake(int dx, int dy);
    void blurDown(); // cheap soft blur used on pause/game-over screens

    // Converts the float buffer to 32-bit RGBA with 15-bit-colour ordered dithering.
    // Output format: 0xAABBGGRR in memory order R,G,B,A (SDL_PIXELFORMAT_ABGR8888 on little endian).
    void resolve(uint32_t* out) const;

    Vec3* pixels() { return color_.data(); }

private:
    struct ClipVert {
        Vec4 clip;
        Vec3 col;
        Vec2 uv;
        float fog;
    };
    void rasterTri(const ClipVert& a, const ClipVert& b, const ClipVert& c, int tex, bool cull);
    void clipAndDraw(ClipVert v[3], int tex, bool cull);

    std::vector<Vec3> color_;
    std::vector<float> depth_;
    std::vector<Texture> textures_;

    Mat4 view_, proj_, viewProj_;
    Vec3 eye_;
    Vec3 ambient_{0.2f, 0.2f, 0.2f};
    std::vector<Light> lights_;
    Vec3 fogColor_;
    float fogNear_ = 5, fogFar_ = 20;
};

// UTF-8 helper
std::vector<uint32_t> utf8Decode(const std::string& s);
