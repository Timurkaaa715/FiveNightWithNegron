#pragma once
#include <vector>
#include "Math.h"

// Low-poly mesh made of independent triangles (PS2-style: vertex colours + small textures).
struct Vertex {
    Vec3 p;
    Vec3 n;
    Vec3 c{1, 1, 1};
    Vec2 uv;
};

struct Tri {
    Vertex v[3];
    int tex = -1;          // texture id, -1 = untextured
    bool emissive = false; // ignores lighting (screens, lamps, glowing eyes)
};

struct Mesh {
    std::vector<Tri> tris;
    bool cull = true;

    void append(const Mesh& o, const Mat4& xf);
    void clear() { tris.clear(); }
};

// Material used by the builders below.
struct Mat {
    Vec3 color{1, 1, 1};
    int tex = -1;
    float uvScale = 1.0f;  // texture repeats per metre; negative = stretch texture N times over the quad
    bool emissive = false;
    Mat() = default;
    Mat(Vec3 c, int t = -1, float s = 1.0f, bool e = false) : color(c), tex(t), uvScale(s), emissive(e) {}
};

namespace build {
// Axis-aligned box centred at c with half-size h. `inside` flips faces (for rooms).
// `subdiv` splits faces into a grid so vertex lighting looks smoother.
void box(Mesh& m, Vec3 c, Vec3 h, const Mat& mat, bool inside = false, int subdiv = 1);
// Single quad, corners in CCW order seen from the front.
void quad(Mesh& m, Vec3 a, Vec3 b, Vec3 c, Vec3 d, const Mat& mat, int subdiv = 1);
// Low-poly ellipsoid.
void ellipsoid(Mesh& m, Vec3 c, Vec3 r, const Mat& mat, int seg = 8, int rings = 6);
// Cylinder along Y, from c.y-h to c.y+h.
void cylinder(Mesh& m, Vec3 c, float r, float h, const Mat& mat, int seg = 8, bool caps = true);
}  // namespace build
