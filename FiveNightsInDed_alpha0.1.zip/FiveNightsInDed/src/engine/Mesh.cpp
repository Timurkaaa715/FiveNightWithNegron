#include "Mesh.h"

void Mesh::append(const Mesh& o, const Mat4& xf) {
    tris.reserve(tris.size() + o.tris.size());
    for (const Tri& t : o.tris) {
        Tri r = t;
        for (auto& v : r.v) {
            v.p = xf.point(v.p);
            v.n = normalize(xf.dir(v.n));
        }
        tris.push_back(r);
    }
}

namespace build {

static void pushTri(Mesh& m, const Vertex& a, const Vertex& b, const Vertex& c, const Mat& mat) {
    Tri t;
    t.v[0] = a; t.v[1] = b; t.v[2] = c;
    t.tex = mat.tex;
    t.emissive = mat.emissive;
    m.tris.push_back(t);
}

void quad(Mesh& m, Vec3 a, Vec3 b, Vec3 c, Vec3 d, const Mat& mat, int subdiv) {
    // a-b-c-d counter-clockwise; normal = (b-a)x(d-a)
    Vec3 n = normalize(cross(b - a, d - a));
    float lu = length(b - a), lv = length(d - a);
    int s = subdiv < 1 ? 1 : subdiv;
    for (int j = 0; j < s; ++j)
        for (int i = 0; i < s; ++i) {
            float u0 = float(i) / s, u1 = float(i + 1) / s;
            float v0 = float(j) / s, v1 = float(j + 1) / s;
            auto P = [&](float u, float v) {
                Vec3 ab = lerp(a, b, u), dc = lerp(d, c, u);
                return lerp(ab, dc, v);
            };
            auto V = [&](float u, float v) {
                Vertex vx;
                vx.p = P(u, v);
                vx.n = n;
                vx.c = mat.color;
                vx.uv = mat.uvScale < 0 ? Vec2(u * -mat.uvScale, v * -mat.uvScale)  // negative = stretch whole texture
                                        : Vec2(u * lu * mat.uvScale, v * lv * mat.uvScale);
                return vx;
            };
            Vertex p00 = V(u0, v0), p10 = V(u1, v0), p11 = V(u1, v1), p01 = V(u0, v1);
            pushTri(m, p00, p10, p11, mat);
            pushTri(m, p00, p11, p01, mat);
        }
}

void box(Mesh& m, Vec3 c, Vec3 h, const Mat& mat, bool inside, int subdiv) {
    Vec3 p[8];
    for (int i = 0; i < 8; ++i)
        p[i] = Vec3(c.x + ((i & 1) ? h.x : -h.x), c.y + ((i & 2) ? h.y : -h.y), c.z + ((i & 4) ? h.z : -h.z));
    // faces as CCW from outside: (a,b,c,d)
    int f[6][4] = {
        {4, 5, 7, 6},  // +z
        {1, 0, 2, 3},  // -z
        {5, 1, 3, 7},  // +x
        {0, 4, 6, 2},  // -x
        {6, 7, 3, 2},  // +y
        {0, 1, 5, 4},  // -y
    };
    for (auto& fc : f) {
        if (!inside)
            quad(m, p[fc[0]], p[fc[1]], p[fc[2]], p[fc[3]], mat, subdiv);
        else
            quad(m, p[fc[1]], p[fc[0]], p[fc[3]], p[fc[2]], mat, subdiv);
    }
}

void ellipsoid(Mesh& m, Vec3 c, Vec3 r, const Mat& mat, int seg, int rings) {
    auto pt = [&](int i, int j, Vertex& v) {
        float th = 2 * PI * i / seg;
        float ph = PI * j / rings;
        Vec3 d(std::sin(ph) * std::cos(th), std::cos(ph), std::sin(ph) * std::sin(th));
        v.p = c + Vec3(d.x * r.x, d.y * r.y, d.z * r.z);
        v.n = normalize(Vec3(d.x / r.x, d.y / r.y, d.z / r.z));
        v.c = mat.color;
        v.uv = Vec2(float(i) / seg * mat.uvScale, float(j) / rings * mat.uvScale);
    };
    for (int j = 0; j < rings; ++j)
        for (int i = 0; i < seg; ++i) {
            Vertex a, b, cc, d;
            pt(i, j, a); pt(i + 1, j, b); pt(i + 1, j + 1, cc); pt(i, j + 1, d);
            if (j != 0) pushTri(m, a, b, cc, mat);
            if (j != rings - 1) pushTri(m, a, cc, d, mat);
        }
}

void cylinder(Mesh& m, Vec3 c, float r, float h, const Mat& mat, int seg, bool caps) {
    for (int i = 0; i < seg; ++i) {
        float a0 = 2 * PI * i / seg, a1 = 2 * PI * (i + 1) / seg;
        Vec3 d0(std::cos(a0), 0, std::sin(a0)), d1(std::cos(a1), 0, std::sin(a1));
        Vertex v[4];
        v[0].p = c + Vec3(d0.x * r, -h, d0.z * r); v[0].n = d0;
        v[1].p = c + Vec3(d1.x * r, -h, d1.z * r); v[1].n = d1;
        v[2].p = c + Vec3(d1.x * r, h, d1.z * r); v[2].n = d1;
        v[3].p = c + Vec3(d0.x * r, h, d0.z * r); v[3].n = d0;
        for (int k = 0; k < 4; ++k) v[k].c = mat.color;
        v[0].uv = Vec2(float(i) / seg, 1); v[1].uv = Vec2(float(i + 1) / seg, 1);
        v[2].uv = Vec2(float(i + 1) / seg, 0); v[3].uv = Vec2(float(i) / seg, 0);
        pushTri(m, v[0], v[2], v[1], mat);
        pushTri(m, v[0], v[3], v[2], mat);
        if (caps) {
            Vertex t0, t1, t2;
            t0.p = c + Vec3(0, h, 0); t1.p = v[3].p; t2.p = v[2].p;
            t0.n = t1.n = t2.n = Vec3(0, 1, 0);
            t0.c = t1.c = t2.c = mat.color;
            pushTri(m, t0, t2, t1, mat);
            Vertex b0, b1, b2;
            b0.p = c + Vec3(0, -h, 0); b1.p = v[0].p; b2.p = v[1].p;
            b0.n = b1.n = b2.n = Vec3(0, -1, 0);
            b0.c = b1.c = b2.c = mat.color;
            pushTri(m, b0, b1, b2, mat);
        }
    }
}

}  // namespace build
