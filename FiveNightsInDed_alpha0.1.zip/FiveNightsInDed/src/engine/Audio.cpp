#include "Audio.h"
#include "Math.h"
#include <cmath>

namespace {

using Buf = std::vector<float>;
constexpr int R = Audio::RATE;

Buf silence(float sec) { return Buf(size_t(sec * R), 0.0f); }

float env(float t, float a, float d, float total) {
    if (t < a) return t / a;
    float rel = total - d;
    if (t > rel) return clampf((total - t) / d, 0, 1);
    return 1.0f;
}

// one-pole low-pass state helper
struct LP {
    float y = 0;
    float k;
    explicit LP(float cutoff) { k = 1.0f - std::exp(-2.0f * PI * cutoff / R); }
    float operator()(float x) { y += k * (x - y); return y; }
};

Buf hum() {
    Buf b = silence(2.0f);  // loop: 2s exactly, integer number of cycles of 50Hz
    for (size_t i = 0; i < b.size(); ++i) {
        float t = float(i) / R;
        b[i] = 0.18f * std::sin(2 * PI * 50 * t) + 0.08f * std::sin(2 * PI * 100 * t) + 0.03f * std::sin(2 * PI * 150 * t);
    }
    Rng r(3); LP lp(300);
    for (auto& s : b) s += lp(r.range(-1, 1)) * 0.25f;
    return b;
}

Buf staticNoise() {
    Buf b = silence(1.0f);
    Rng r(9); LP lp(5000);
    for (size_t i = 0; i < b.size(); ++i) {
        float crackle = (r.f01() > 0.995f) ? r.range(-1, 1) : 0.0f;
        b[i] = lp(r.range(-1, 1)) * 0.35f + crackle * 0.4f;
    }
    return b;
}

Buf blip(float f, float len) {
    Buf b = silence(len);
    for (size_t i = 0; i < b.size(); ++i) {
        float t = float(i) / R;
        b[i] = (std::sin(2 * PI * f * t) > 0 ? 0.3f : -0.3f) * env(t, 0.002f, len * 0.6f, len);
    }
    return b;
}

Buf door(bool closing) {
    float len = closing ? 0.7f : 0.5f;
    Buf b = silence(len);
    Rng r(closing ? 17 : 18); LP lp(closing ? 900 : 1500);
    for (size_t i = 0; i < b.size(); ++i) {
        float t = float(i) / R;
        float slide = lp(r.range(-1, 1)) * 0.5f * (t < len * 0.6f ? 1.0f : 0.2f);
        float clang = 0;
        float tc = t - len * 0.55f;
        if (closing && tc > 0)
            clang = (std::sin(2 * PI * 95 * tc) * 0.8f + std::sin(2 * PI * 211 * tc) * 0.4f + r.range(-1, 1) * 0.3f) * std::exp(-tc * 12);
        b[i] = (slide + clang) * env(t, 0.01f, 0.05f, len);
    }
    return b;
}

Buf buzz() {
    Buf b = silence(1.0f);
    for (size_t i = 0; i < b.size(); ++i) {
        float t = float(i) / R;
        float saw = std::fmod(t * 120.0f, 1.0f) * 2 - 1;
        b[i] = saw * 0.12f + std::sin(2 * PI * 60 * t) * 0.1f;
    }
    return b;
}

Buf footstep() {
    float len = 0.35f;
    Buf b = silence(len);
    Rng r(23); LP lp(220);
    for (size_t i = 0; i < b.size(); ++i) {
        float t = float(i) / R;
        b[i] = (std::sin(2 * PI * 55 * t) * 0.9f + lp(r.range(-1, 1)) * 1.5f) * std::exp(-t * 14);
    }
    return b;
}

Buf canOpen() {
    float len = 0.9f;
    Buf b = silence(len);
    Rng r(29);
    float hp = 0, prev = 0;
    for (size_t i = 0; i < b.size(); ++i) {
        float t = float(i) / R;
        float click = t < 0.015f ? r.range(-1, 1) * (1 - t / 0.015f) : 0;
        float n = r.range(-1, 1);
        hp = 0.85f * (hp + n - prev); prev = n;  // high-pass
        float hiss = hp * 0.35f * (t > 0.01f ? std::exp(-(t - 0.01f) * 3.5f) : 0);
        b[i] = click * 0.8f + hiss;
    }
    return b;
}

Buf glug() {
    float len = 1.2f;
    Buf b = silence(len);
    for (size_t i = 0; i < b.size(); ++i) {
        float t = float(i) / R;
        float ph = std::fmod(t * 5.0f, 1.0f);
        float f = 180 + 220 * ph;
        b[i] = std::sin(2 * PI * f * t) * std::exp(-ph * 6) * 0.4f * env(t, 0.02f, 0.2f, len);
    }
    return b;
}

Buf burp() {
    float len = 1.1f;
    Buf b = silence(len);
    Rng r(31); LP lp(700);
    float ph = 0;
    for (size_t i = 0; i < b.size(); ++i) {
        float t = float(i) / R;
        float f = 78 - 22 * t + 6 * std::sin(t * 37);
        ph += f / R;
        float pulse = std::fmod(ph, 1.0f) < 0.25f ? 1.0f : -0.3f;  // glottal pulse
        float rough = 1.0f + 0.5f * r.range(-1, 1);
        b[i] = lp(pulse * rough) * 1.4f * env(t, 0.03f, 0.25f, len);
    }
    return b;
}

Buf creak() {
    float len = 1.0f;
    Buf b = silence(len);
    float ph = 0;
    Rng r(37);
    for (size_t i = 0; i < b.size(); ++i) {
        float t = float(i) / R;
        float f = 320 + 160 * std::sin(t * 4.0f) + 40 * r.range(-1, 1);
        ph += f / R;
        float s = std::fmod(ph, 1.0f) < 0.1f ? 0.6f : 0.0f;
        b[i] = s * env(t, 0.1f, 0.3f, len) * (0.6f + 0.4f * std::sin(t * 40));
    }
    return b;
}

Buf bang() {
    float len = 0.5f;
    Buf b = silence(len);
    Rng r(41); LP lp(400);
    for (size_t i = 0; i < b.size(); ++i) {
        float t = float(i) / R;
        b[i] = (lp(r.range(-1, 1)) * 2.2f + std::sin(2 * PI * 70 * t) * 0.9f + std::sin(2 * PI * 143 * t) * 0.3f) * std::exp(-t * 9);
    }
    return b;
}

Buf scream() {
    float len = 1.8f;
    Buf b = silence(len);
    Rng r(43);
    float p1 = 0, p2 = 0, p3 = 0;
    for (size_t i = 0; i < b.size(); ++i) {
        float t = float(i) / R;
        float f = 620 - 180 * t + 40 * std::sin(t * 70);
        p1 += f / R; p2 += f * 1.49f / R; p3 += f * 0.51f / R;
        float s = (std::fmod(p1, 1.0f) * 2 - 1) + (std::fmod(p2, 1.0f) * 2 - 1) * 0.7f + (std::fmod(p3, 1.0f) * 2 - 1) * 0.8f;
        s += r.range(-1, 1) * 0.9f;
        s = std::tanh(s * 1.8f);  // distortion
        b[i] = s * 0.7f * env(t, 0.005f, 0.4f, len);
    }
    return b;
}

Buf chime() {
    float len = 4.0f;
    Buf b = silence(len);
    const float notes[] = {659.25f, 523.25f, 587.33f, 392.0f};
    for (int n = 0; n < 4; ++n) {
        float start = n * 0.55f;
        for (size_t i = size_t(start * R); i < b.size(); ++i) {
            float t = float(i) / R - start;
            float e = std::exp(-t * 1.6f);
            b[i] += (std::sin(2 * PI * notes[n] * t) + 0.4f * std::sin(2 * PI * notes[n] * 2.76f * t) * std::exp(-t * 4)) * e * 0.25f;
        }
    }
    return b;
}

Buf powerDown() {
    float len = 2.5f;
    Buf b = silence(len);
    float ph = 0;
    for (size_t i = 0; i < b.size(); ++i) {
        float t = float(i) / R;
        float f = 400 * std::exp(-t * 1.8f) + 30;
        ph += f / R;
        b[i] = (std::fmod(ph, 1.0f) * 2 - 1) * 0.3f * env(t, 0.01f, 0.5f, len);
    }
    return b;
}

Buf crowd() {
    Buf b = silence(3.0f);
    Rng r(47); LP lp(900); LP lp2(2);
    for (size_t i = 0; i < b.size(); ++i) {
        float t = float(i) / R;
        float swell = 0.6f + 0.4f * std::sin(2 * PI * t / 3.0f);
        b[i] = lp(r.range(-1, 1)) * 0.6f * swell + std::sin(2 * PI * 440 * t) * 0.02f * (std::fmod(t, 1.5f) < 0.1f);
    }
    // crossfade ends to make the loop seamless
    size_t fade = R / 10;
    for (size_t i = 0; i < fade; ++i) {
        float k = float(i) / fade;
        b[i] = b[i] * k + b[b.size() - fade + i] * (1 - k);
    }
    b.resize(b.size() - fade);
    return b;
}

Buf fridge() {
    Buf b = silence(1.0f);
    for (size_t i = 0; i < b.size(); ++i) {
        float t = float(i) / R;
        b[i] = std::sin(2 * PI * 60 * t) * 0.15f + std::sin(2 * PI * 120 * t) * 0.1f + std::sin(2 * PI * 241 * t) * 0.02f;
    }
    return b;
}

Buf logoSting() {
    float len = 3.0f;
    Buf b = silence(len);
    Rng r(53);
    const float f[] = {55.0f, 65.41f, 82.41f, 103.83f};  // dark chord
    for (size_t i = 0; i < b.size(); ++i) {
        float t = float(i) / R;
        float s = 0;
        for (float fr : f) s += std::sin(2 * PI * fr * t + std::sin(2 * PI * fr * 2 * t) * 0.8f);
        float hit = r.range(-1, 1) * std::exp(-t * 18);
        b[i] = (s * 0.18f + hit * 0.6f) * env(t, 0.01f, 1.4f, len);
    }
    return b;
}

}  // namespace

void Audio::init() {
    sounds_.resize(size_t(Sfx::Count));
    sounds_[int(Sfx::Hum)] = hum();
    sounds_[int(Sfx::Static)] = staticNoise();
    sounds_[int(Sfx::CamBlip)] = blip(880, 0.08f);
    sounds_[int(Sfx::MonitorUp)] = blip(330, 0.15f);
    sounds_[int(Sfx::DoorClose)] = door(true);
    sounds_[int(Sfx::DoorOpen)] = door(false);
    sounds_[int(Sfx::LightBuzz)] = buzz();
    sounds_[int(Sfx::Footstep)] = footstep();
    sounds_[int(Sfx::CanOpen)] = canOpen();
    sounds_[int(Sfx::Glug)] = glug();
    sounds_[int(Sfx::Burp)] = burp();
    sounds_[int(Sfx::CouchCreak)] = creak();
    sounds_[int(Sfx::DoorBang)] = bang();
    sounds_[int(Sfx::Scream)] = scream();
    sounds_[int(Sfx::Chime)] = chime();
    sounds_[int(Sfx::PowerDown)] = powerDown();
    sounds_[int(Sfx::TvCrowd)] = crowd();
    sounds_[int(Sfx::FridgeHum)] = fridge();
    sounds_[int(Sfx::LogoSting)] = logoSting();
    sounds_[int(Sfx::Click)] = blip(1200, 0.04f);
}

int Audio::play(Sfx s, float volume, float pan, bool loop, float pitch) {
    std::lock_guard<std::mutex> lk(mtx_);
    if (voices_.size() > 24) return -1;
    Voice v;
    v.sfx = int(s);
    v.vol = volume;
    v.pan = pan;
    v.loop = loop;
    v.pitch = pitch;
    v.id = nextId_++;
    voices_.push_back(v);
    return v.id;
}

void Audio::stop(int handle) {
    std::lock_guard<std::mutex> lk(mtx_);
    for (size_t i = 0; i < voices_.size(); ++i)
        if (voices_[i].id == handle) { voices_.erase(voices_.begin() + i); return; }
}

void Audio::setVolume(int handle, float volume) {
    std::lock_guard<std::mutex> lk(mtx_);
    for (auto& v : voices_)
        if (v.id == handle) v.vol = volume;
}

void Audio::stopAll() {
    std::lock_guard<std::mutex> lk(mtx_);
    voices_.clear();
}

void Audio::mix(float* out, int frames) {
    std::lock_guard<std::mutex> lk(mtx_);
    for (int i = 0; i < frames * 2; ++i) out[i] = 0;
    for (size_t vi = 0; vi < voices_.size();) {
        Voice& v = voices_[vi];
        const auto& buf = sounds_[v.sfx];
        bool done = false;
        float l = v.vol * clampf(1 - v.pan, 0, 1);
        float r = v.vol * clampf(1 + v.pan, 0, 1);
        for (int i = 0; i < frames; ++i) {
            size_t p = size_t(v.pos);
            if (p >= buf.size()) {
                if (v.loop) { v.pos -= buf.size(); p = size_t(v.pos); }
                else { done = true; break; }
            }
            float s = buf[p];
            out[i * 2] += s * l;
            out[i * 2 + 1] += s * r;
            v.pos += v.pitch;
        }
        if (done) voices_.erase(voices_.begin() + vi);
        else ++vi;
    }
    for (int i = 0; i < frames * 2; ++i) out[i] = std::tanh(out[i] * master_);
}
