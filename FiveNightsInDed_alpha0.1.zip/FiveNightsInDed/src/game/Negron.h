#pragma once
#include "../engine/Math.h"
#include "../engine/Mesh.h"
#include "../engine/Renderer.h"
#include "../engine/Textures.h"

// ============================================================================
//  НЕГРОН — first animatronic-of-sorts of "5 Nights in Ded".
//  Lives on the couch. Loves beer and the couch more than anything.
//
//  Core mechanic — "Пивной баланс" (beer balance):
//   * While on the couch his THIRST grows. Feed him beer through the
//     beer pipe (CAM 1 / CAM 2 button) to keep him seated.
//   * Football on the TV slows his thirst (costs power).
//   * Every can adds DRUNKENNESS. At 100% he goes on a RAMPAGE:
//     skips the kitchen and charges the office twice as fast.
//   * Thirst at 100% -> he gets up (couch creak + burp), searches the
//     kitchen, then walks the corridor to your door.
//   * In the kitchen you can lure him back with a can ("pssht" sound).
//   * At the door: close it in time. He bangs, gives up and goes back.
//     A blocked rampage makes him pass out on the couch for a while.
// ============================================================================

enum class NegronLoc { Sofa, Kitchen, Corridor, Door, Gone };

struct NegronEvents {
    // one-shot events for sound/visual feedback, cleared every update
    bool gotUp = false;
    bool burp = false;
    bool footstep = false;
    float footstepVolume = 0;
    bool reachedDoor = false;
    bool bang = false;
    bool leftDoor = false;
    bool attack = false;
    bool movedRoom = false;  // camera glitch
    bool lured = false;
    bool drank = false;
    bool rampageStart = false;
    bool passedOut = false;
};

class NegronAI {
public:
    void reset(int aiLevel, uint32_t seed);
    // doorClosed: is the office door shut right now
    void update(float dt, bool doorClosed, bool tvOn);
    // Player sent a can through the beer pipe. Returns true if he drank it.
    bool deliverBeer();
    // Power outage: he comes no matter what.
    void forcePowerOutAttack();

    NegronLoc loc() const { return loc_; }
    float thirst() const { return thirst_; }
    float drunk() const { return drunk_; }
    bool rampage() const { return rampage_; }
    bool sneaking() const { return sneak_; }  // tiptoeing through the corridor: barely audible
    bool asleep() const { return sleepTimer_ > 0; }
    float progress() const;          // 0..1 progress inside the current room
    float drinkAnim() const { return drinkAnim_; }
    float stateTime() const { return stateTime_; }
    const NegronEvents& events() const { return ev_; }
    int level() const { return level_; }
    // test hook: put him somewhere specific
    void debugForce(NegronLoc l, float duration, bool rampage = false, float stateTime = 0) {
        go(l, duration); rampage_ = rampage; stateTime_ = stateTime; attackTimer_ = 99; bangTimer_ = 3;
    }

private:
    void go(NegronLoc l, float duration);
    Rng rng_;
    int level_ = 0;
    NegronLoc loc_ = NegronLoc::Sofa;
    float thirst_ = 20;
    float drunk_ = 0;
    bool rampage_ = false;
    bool sneak_ = false;
    float stateTime_ = 0;
    float stateDuration_ = 0;
    float attackTimer_ = 0;
    float bangTimer_ = 0;
    float bangTick_ = 0;
    float stepTick_ = 0;
    float sleepTimer_ = 0;
    float drinkAnim_ = 0;
    float burpTimer_ = 8;
    bool blocked_ = false;
    NegronEvents ev_;
};

// ---------------------------------------------------------------------------
// Low-poly model (built from the reference photo: black bomber jacket with a
// white chest logo, green sweatshirt, dark jeans, short dark-brown hair, smirk).
// ---------------------------------------------------------------------------
struct NegronPose {
    float torsoPitch = 0, torsoYaw = 0;
    float headYaw = 0, headPitch = 0, headRoll = 0;
    float shoulderL = 0, shoulderR = 0, shoulderRollL = 0, shoulderRollR = 0;
    float elbowL = 0, elbowR = 0;
    float hipL = 0, hipR = 0, kneeL = 0, kneeR = 0;
    bool canInHand = true;
    bool glowEyes = false;
    bool mouthOpen = false;
    bool redEyes = false;
};

class NegronModel {
public:
    void build(const TextureSet& tx);
    void draw(Renderer& r, const Mat4& root, const NegronPose& p) const;

    static NegronPose sitting(float t, float drink, bool asleep);
    static NegronPose standing(float t, float lookBack);
    static NegronPose walking(float t, bool rampage);
    static NegronPose atDoor(float t, bool rampage);
    static NegronPose lunge(float t);

private:
    Mesh torso_, head_, eyes_, eyesGlow_, eyesRed_, mouthSmile_, mouthOpen_;
    Mesh upperArm_, foreArm_, thigh_, shin_, can_;
};
