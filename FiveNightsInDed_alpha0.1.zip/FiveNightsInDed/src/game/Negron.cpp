#include "Negron.h"

// ============================================================ AI

void NegronAI::reset(int aiLevel, uint32_t seed) {
    rng_ = Rng(seed);
    level_ = aiLevel;
    loc_ = NegronLoc::Sofa;
    thirst_ = 15 + rng_.range(0, 15);
    drunk_ = 0;
    rampage_ = false;
    stateTime_ = 0;
    stateDuration_ = 0;
    attackTimer_ = 0;
    bangTimer_ = 0;
    sleepTimer_ = 0;
    drinkAnim_ = 0;
    blocked_ = false;
    burpTimer_ = rng_.range(6, 14);
    ev_ = {};
}

void NegronAI::go(NegronLoc l, float duration) {
    if (l == NegronLoc::Corridor)
        sneak_ = !rampage_ && level_ >= 8 && rng_.f01() < 0.25f + level_ * 0.015f;
    loc_ = l;
    stateTime_ = 0;
    stateDuration_ = duration;
    ev_.movedRoom = true;
}

float NegronAI::progress() const {
    if (stateDuration_ <= 0) return 0;
    return clampf(stateTime_ / stateDuration_, 0, 1);
}

bool NegronAI::deliverBeer() {
    if (loc_ == NegronLoc::Sofa) {
        thirst_ = std::max(0.0f, thirst_ - 55.0f);
        drunk_ += 20.0f;
        drinkAnim_ = 2.4f;
        ev_.drank = true;
        if (sleepTimer_ > 0) sleepTimer_ = std::max(0.0f, sleepTimer_ - 5.0f);  // wakes him up a bit
        return true;
    }
    if (loc_ == NegronLoc::Kitchen) {
        // He hears "pssht" from the living room and maybe goes back.
        float chance = clampf(0.7f - level_ * 0.02f, 0.35f, 0.7f);
        if (rng_.f01() < chance) {
            go(NegronLoc::Sofa, 0);
            thirst_ = 25.0f;
            drunk_ += 18.0f;
            drinkAnim_ = 2.4f;
            ev_.lured = true;
            ev_.drank = true;
            return true;
        }
    }
    return false;  // in the corridor or at the door he can't hear it any more
}

void NegronAI::forcePowerOutAttack() {
    rampage_ = false;
    go(NegronLoc::Door, 0);
    attackTimer_ = 1e9f;  // handled by game power-out sequence
}

void NegronAI::update(float dt, bool doorClosed, bool tvOn) {
    ev_ = {};
    stateTime_ += dt;
    if (drinkAnim_ > 0) drinkAnim_ -= dt;
    drunk_ = std::max(0.0f, drunk_ - 0.12f * dt);

    burpTimer_ -= dt;
    if (burpTimer_ <= 0) {
        burpTimer_ = rng_.range(14, 30);
        if (loc_ == NegronLoc::Sofa || loc_ == NegronLoc::Kitchen) ev_.burp = true;
    }

    float L = float(level_);
    switch (loc_) {
    case NegronLoc::Sofa: {
        if (sleepTimer_ > 0) { sleepTimer_ -= dt; break; }
        float rate = 0.8f + L * 0.13f;
        if (tvOn) rate *= 0.6f;
        thirst_ += rate * dt;
        if (drunk_ >= 100.0f) {
            rampage_ = true;
            ev_.rampageStart = true;
            ev_.gotUp = true;
            ev_.burp = true;
            go(NegronLoc::Corridor, std::max(2.5f, (9.0f - L * 0.2f) * 0.5f));
        } else if (thirst_ >= 100.0f) {
            thirst_ = 100.0f;
            ev_.gotUp = true;
            go(NegronLoc::Kitchen, std::max(5.0f, rng_.range(10, 15) - L * 0.3f));
        }
        break;
    }
    case NegronLoc::Kitchen:
        if (stateTime_ >= stateDuration_) go(NegronLoc::Corridor, std::max(4.0f, rng_.range(7, 11) - L * 0.25f));
        break;
    case NegronLoc::Corridor: {
        float stepInterval = rampage_ ? 0.32f : 0.6f;
        stepTick_ -= dt;
        if (stepTick_ <= 0) {
            stepTick_ = stepInterval;
            ev_.footstep = true;
            ev_.footstepVolume = (0.15f + 0.6f * progress()) * (sneak_ ? 0.12f : 1.0f);
        }
        if (stateTime_ >= stateDuration_) {
            go(NegronLoc::Door, 0);
            ev_.reachedDoor = true;
            blocked_ = false;
            attackTimer_ = std::max(1.2f, 3.5f - L * 0.15f) * (rampage_ ? 0.6f : 1.0f);
            bangTimer_ = rampage_ ? rng_.range(5, 7) : rng_.range(4, 7);
            bangTick_ = 0.3f;
        }
        break;
    }
    case NegronLoc::Door: {
        if (doorClosed) {
            blocked_ = true;
            bangTimer_ -= dt;
            bangTick_ -= dt;
            if (bangTick_ <= 0) {
                bangTick_ = rampage_ ? rng_.range(0.5f, 0.9f) : rng_.range(1.1f, 1.8f);
                ev_.bang = true;
            }
            if (bangTimer_ <= 0) {
                // Gives up and shuffles back to the couch.
                ev_.leftDoor = true;
                if (rampage_) {
                    rampage_ = false;
                    drunk_ = 30.0f;
                    sleepTimer_ = 25.0f;  // passes out
                    ev_.passedOut = true;
                }
                thirst_ = 25.0f;
                go(NegronLoc::Sofa, 0);
            }
        } else {
            if (blocked_) {  // player opened the door while he was still there
                blocked_ = false;
                attackTimer_ = std::min(attackTimer_, 1.0f);
            }
            attackTimer_ -= dt;
            if (attackTimer_ <= 0) {
                ev_.attack = true;
                go(NegronLoc::Gone, 0);
            }
        }
        break;
    }
    case NegronLoc::Gone:
        break;
    }
}

// ============================================================ MODEL

namespace {
const Vec3 SKIN = rgb(226, 182, 156);
const Vec3 SKIN_DARK = rgb(200, 150, 125);
const Vec3 HAIR = rgb(58, 40, 28);
const Vec3 JACKET = rgb(24, 24, 26);
const Vec3 SWEAT = rgb(78, 120, 72);
const Vec3 JEANS = rgb(30, 32, 40);
}  // namespace

void NegronModel::build(const TextureSet& tx) {
    using namespace build;
    // ---- torso (origin at hips, extends +y). Character faces +z.
    torso_.clear();
    box(torso_, Vec3(0, 0.29f, 0), Vec3(0.17f, 0.27f, 0.105f), Mat(SWEAT));            // green sweatshirt
    box(torso_, Vec3(0, 0.36f, 0.106f), Vec3(0.045f, 0.03f, 0.003f), Mat(rgb(20, 20, 20)));  // "MAN" lettering
    box(torso_, Vec3(0, 0.36f, 0.104f), Vec3(0.05f, 0.036f, 0.002f), Mat(rgb(220, 220, 220)));
    box(torso_, Vec3(-0.125f, 0.30f, 0.0f), Vec3(0.085f, 0.29f, 0.125f), Mat(JACKET));  // jacket left half
    box(torso_, Vec3(0.125f, 0.30f, 0.0f), Vec3(0.085f, 0.29f, 0.125f), Mat(JACKET));   // jacket right half
    box(torso_, Vec3(0, 0.30f, -0.1f), Vec3(0.2f, 0.29f, 0.03f), Mat(JACKET));
    box(torso_, Vec3(0, 0.585f, 0), Vec3(0.13f, 0.025f, 0.11f), Mat(rgb(15, 15, 15)));  // ribbed collar
    box(torso_, Vec3(0.13f, 0.43f, 0.127f), Vec3(0.04f, 0.04f, 0.003f), Mat(rgb(235, 235, 225)));  // Off-White style patch
    box(torso_, Vec3(0.13f, 0.43f, 0.129f), Vec3(0.022f, 0.022f, 0.002f), Mat(rgb(230, 170, 40)));
    box(torso_, Vec3(0, 0.0f, 0), Vec3(0.18f, 0.07f, 0.11f), Mat(JEANS));               // hips / jeans
    box(torso_, Vec3(0, 0.035f, 0.0f), Vec3(0.205f, 0.03f, 0.13f), Mat(rgb(18, 18, 18)));  // jacket waistband

    // ---- head (origin at neck base)
    head_.clear();
    cylinder(head_, Vec3(0, 0.04f, 0), 0.05f, 0.05f, Mat(SKIN), 8);
    ellipsoid(head_, Vec3(0, 0.17f, 0.01f), Vec3(0.105f, 0.13f, 0.115f), Mat(SKIN), 10, 8);
    ellipsoid(head_, Vec3(0, 0.25f, -0.005f), Vec3(0.112f, 0.09f, 0.122f), Mat(HAIR), 10, 6);  // short haircut
    ellipsoid(head_, Vec3(-0.105f, 0.165f, 0), Vec3(0.02f, 0.035f, 0.025f), Mat(SKIN_DARK), 6, 4);
    ellipsoid(head_, Vec3(0.105f, 0.165f, 0), Vec3(0.02f, 0.035f, 0.025f), Mat(SKIN_DARK), 6, 4);
    box(head_, Vec3(-0.042f, 0.207f, 0.112f), Vec3(0.026f, 0.006f, 0.006f), Mat(HAIR));  // brows
    box(head_, Vec3(0.042f, 0.207f, 0.112f), Vec3(0.026f, 0.006f, 0.006f), Mat(HAIR));
    box(head_, Vec3(0, 0.148f, 0.122f), Vec3(0.015f, 0.03f, 0.016f), Mat(SKIN_DARK));  // nose

    eyes_.clear();
    for (int s = -1; s <= 1; s += 2) {
        box(eyes_, Vec3(s * 0.042f, 0.182f, 0.111f), Vec3(0.019f, 0.009f, 0.004f), Mat(rgb(235, 230, 220)));
        box(eyes_, Vec3(s * 0.042f + 0.008f, 0.182f, 0.115f), Vec3(0.008f, 0.008f, 0.003f), Mat(rgb(40, 30, 20)));
    }
    eyesGlow_.clear();
    for (int s = -1; s <= 1; s += 2)
        box(eyesGlow_, Vec3(s * 0.042f, 0.182f, 0.113f), Vec3(0.02f, 0.011f, 0.005f), Mat(rgb(255, 255, 230), -1, 1, true));
    eyesRed_.clear();
    for (int s = -1; s <= 1; s += 2)
        box(eyesRed_, Vec3(s * 0.042f, 0.182f, 0.113f), Vec3(0.02f, 0.011f, 0.005f), Mat(rgb(255, 40, 30), -1, 1, true));

    mouthSmile_.clear();
    box(mouthSmile_, Vec3(0.005f, 0.103f, 0.108f), Vec3(0.032f, 0.005f, 0.004f), Mat(rgb(120, 60, 55)));
    box(mouthSmile_, Vec3(0.036f, 0.109f, 0.104f), Vec3(0.008f, 0.005f, 0.004f), Mat(rgb(120, 60, 55)));  // smirk corner

    mouthOpen_.clear();
    box(mouthOpen_, Vec3(0, 0.095f, 0.106f), Vec3(0.045f, 0.035f, 0.006f), Mat(rgb(15, 0, 0)));
    for (int i = -3; i <= 3; ++i) {
        box(mouthOpen_, Vec3(i * 0.012f, 0.124f, 0.11f), Vec3(0.005f, 0.007f, 0.003f), Mat(rgb(230, 225, 200)));
        box(mouthOpen_, Vec3(i * 0.012f, 0.066f, 0.11f), Vec3(0.005f, 0.007f, 0.003f), Mat(rgb(230, 225, 200)));
    }

    // ---- limbs (origin at joint, extend -y)
    upperArm_.clear();
    box(upperArm_, Vec3(0, -0.15f, 0), Vec3(0.058f, 0.16f, 0.062f), Mat(JACKET));
    foreArm_.clear();
    box(foreArm_, Vec3(0, -0.13f, 0), Vec3(0.052f, 0.14f, 0.056f), Mat(JACKET));
    box(foreArm_, Vec3(0, -0.265f, 0), Vec3(0.048f, 0.02f, 0.05f), Mat(rgb(14, 14, 14)));  // cuff
    ellipsoid(foreArm_, Vec3(0, -0.33f, 0.005f), Vec3(0.042f, 0.06f, 0.032f), Mat(SKIN), 6, 4);
    thigh_.clear();
    box(thigh_, Vec3(0, -0.22f, 0), Vec3(0.078f, 0.23f, 0.082f), Mat(JEANS));
    shin_.clear();
    box(shin_, Vec3(0, -0.21f, 0), Vec3(0.066f, 0.22f, 0.07f), Mat(JEANS));
    box(shin_, Vec3(0, -0.45f, 0.04f), Vec3(0.062f, 0.04f, 0.12f), Mat(rgb(20, 20, 20)));       // sneakers
    box(shin_, Vec3(0, -0.485f, 0.04f), Vec3(0.064f, 0.01f, 0.122f), Mat(rgb(220, 220, 215)));  // white sole
    can_.clear();
    cylinder(can_, Vec3(0, 0, 0), 0.034f, 0.062f, Mat(Vec3(1, 1, 1), tx.beerLabel), 8);
}

void NegronModel::draw(Renderer& r, const Mat4& root, const NegronPose& p) const {
    Mat4 torso = root * Mat4::rotY(p.torsoYaw) * Mat4::rotX(p.torsoPitch);
    r.drawMesh(torso_, torso);

    Mat4 head = torso * Mat4::translate(Vec3(0, 0.6f, 0)) * Mat4::rotY(p.headYaw) * Mat4::rotX(p.headPitch) * Mat4::rotZ(p.headRoll);
    r.drawMesh(head_, head);
    if (p.redEyes) r.drawMesh(eyesRed_, head);
    else if (p.glowEyes) r.drawMesh(eyesGlow_, head);
    else r.drawMesh(eyes_, head);
    r.drawMesh(p.mouthOpen ? mouthOpen_ : mouthSmile_, head);

    for (int s = -1; s <= 1; s += 2) {
        bool left = s < 0;
        Mat4 sh = torso * Mat4::translate(Vec3(s * 0.25f, 0.5f, 0)) *
                  Mat4::rotZ(left ? -p.shoulderRollL : p.shoulderRollR) * Mat4::rotX(left ? p.shoulderL : p.shoulderR);
        r.drawMesh(upperArm_, sh);
        Mat4 el = sh * Mat4::translate(Vec3(0, -0.3f, 0)) * Mat4::rotX(left ? p.elbowL : p.elbowR);
        r.drawMesh(foreArm_, el);
        if (!left && p.canInHand) r.drawMesh(can_, el * Mat4::translate(Vec3(0, -0.33f, 0.04f)));

        Mat4 hip = root * Mat4::translate(Vec3(s * 0.095f, 0, 0)) * Mat4::rotX(left ? p.hipL : p.hipR);
        r.drawMesh(thigh_, hip);
        Mat4 knee = hip * Mat4::translate(Vec3(0, -0.45f, 0)) * Mat4::rotX(left ? p.kneeL : p.kneeR);
        r.drawMesh(shin_, knee);
    }
}

NegronPose NegronModel::sitting(float t, float drink, bool asleep) {
    NegronPose p;
    p.torsoPitch = -0.28f;  // slouching into the couch
    p.hipL = p.hipR = -1.35f;
    p.kneeL = p.kneeR = 1.45f;
    p.hipL -= 0.05f; p.hipR += 0.05f;
    p.shoulderRollL = 0.35f;  // arm over the armrest
    p.shoulderL = 0.1f;
    p.elbowL = -0.3f;
    p.shoulderR = -0.35f;
    p.elbowR = -1.3f;
    p.headYaw = 0.35f * std::sin(t * 0.3f);  // glancing around like in the photo
    p.headPitch = 0.05f;
    if (drink > 0) {
        float k = smooth01(std::min(drink, 2.4f - drink) * 2.0f);
        p.shoulderR = lerpf(-0.35f, -0.9f, k);
        p.elbowR = lerpf(-1.3f, -2.45f, k);
        p.headPitch = lerpf(0.05f, -0.45f, k);
        p.headYaw *= (1 - k);
    }
    if (asleep) {
        p.headPitch = 0.45f;
        p.headRoll = 0.3f;
        p.headYaw = 0.2f;
        p.elbowR = -0.4f;
        p.shoulderR = 0.0f;
        p.torsoPitch = -0.4f;
    }
    return p;
}

NegronPose NegronModel::standing(float t, float lookBack) {
    NegronPose p;
    p.shoulderR = -0.6f;
    p.elbowR = -0.9f;
    p.shoulderL = -0.9f;  // reaching into the fridge
    p.elbowL = -0.3f;
    p.torsoPitch = 0.12f;
    p.headYaw = -lookBack * 2.4f;  // creepy owl-like head turn toward the camera
    p.headPitch = 0.1f + 0.05f * std::sin(t);
    return p;
}

NegronPose NegronModel::walking(float t, bool rampage) {
    NegronPose p;
    float f = rampage ? 9.0f : 5.0f;
    float s = std::sin(t * f);
    float amp = rampage ? 0.7f : 0.45f;
    p.hipL = s * amp;
    p.hipR = -s * amp;
    p.kneeL = std::max(0.0f, -s) * 0.7f;
    p.kneeR = std::max(0.0f, s) * 0.7f;
    p.shoulderL = -s * 0.4f;
    p.shoulderR = s * 0.3f - 0.3f;
    p.elbowR = -1.0f;
    p.elbowL = -0.3f;
    p.torsoPitch = rampage ? 0.25f : 0.08f;
    p.headPitch = rampage ? -0.25f : 0.0f;
    p.glowEyes = true;
    p.redEyes = rampage;
    return p;
}

NegronPose NegronModel::atDoor(float t, bool rampage) {
    NegronPose p;
    p.torsoPitch = 0.18f;
    p.headPitch = -0.1f + 0.04f * std::sin(t * 2.0f);
    p.headRoll = 0.15f;
    p.shoulderL = -1.3f;  // hand on the door frame
    p.shoulderRollL = 0.5f;
    p.elbowL = -0.4f;
    p.shoulderR = -0.4f;
    p.elbowR = -1.4f;
    p.glowEyes = true;
    p.redEyes = rampage;
    p.mouthOpen = false;
    return p;
}

NegronPose NegronModel::lunge(float t) {
    NegronPose p;
    p.torsoPitch = 0.35f;
    p.shoulderL = p.shoulderR = -2.3f + 0.2f * std::sin(t * 30);
    p.shoulderRollL = p.shoulderRollR = 0.3f;
    p.elbowL = p.elbowR = -0.3f;
    p.headPitch = -0.35f;
    p.headRoll = 0.1f * std::sin(t * 40);
    p.mouthOpen = true;
    p.glowEyes = true;
    p.canInHand = false;
    return p;
}
