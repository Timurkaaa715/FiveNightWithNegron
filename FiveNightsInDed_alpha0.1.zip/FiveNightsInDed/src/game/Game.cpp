#include "Game.h"
#include <cstdio>
#include <fstream>

namespace {
const Vec3 WHITE(0.92f, 0.9f, 0.85f);
const Vec3 RED(0.85f, 0.08f, 0.06f);
const Vec3 DIM(0.5f, 0.5f, 0.48f);
const Vec3 GREEN(0.4f, 0.95f, 0.5f);
const Vec3 YELLOW(0.95f, 0.8f, 0.2f);

const char* CAM_NAMES[3] = {"ГОСТИНАЯ", "КУХНЯ", "КОРИДОР"};

// Night-1 tutorial, delivered as texts from Ded.
const char* SMS[] = {
    "Внучок, я на дачу. Присмотри за квартирой до 6 утра.",
    "На диване Негрон. Он смирный, пока у него есть пиво.",
    "Кончится пиво - встанет. Сначала кухня, потом к тебе.",
    "КАМ 1: кнопка ПОДАТЬ ПИВО шлёт банку по пивопроводу.",
    "Не перепаивай! Пьяный Негрон буянит и прёт напролом.",
    "Футбол по ТВ его успокаивает. Пьёт медленнее.",
    "Услышал шаги - смотри влево, свет, закрывай дверь.",
    "Свет и двери жрут энергию. Удачи. Дед.",
};
constexpr int SMS_COUNT = sizeof(SMS) / sizeof(SMS[0]);
constexpr float SMS_TIME = 5.5f;
}  // namespace

int Game::aiLevelForNight(int n) {
    static const int lv[] = {2, 5, 8, 11, 15};
    return lv[std::clamp(n, 1, 5) - 1];
}
int Game::beerForNight(int n) {
    static const int b[] = {12, 10, 8, 7, 6};
    return b[std::clamp(n, 1, 5) - 1];
}

void Game::init(const std::string& savePath) {
    savePath_ = savePath;
    audio_.init();
    world_.build(renderer_);
    loadSave();
    setState(State::Logo);
}

void Game::loadSave() {
    std::ifstream f(savePath_);
    int n = 1;
    if (f >> n) savedNight_ = std::clamp(n, 1, 5);
}

void Game::writeSave() {
    if (savePath_.empty()) return;
    std::ofstream f(savePath_);
    f << savedNight_ << "\n";
}

void Game::setState(State s) {
    if (s != State::Paused) prevState_ = state_;
    state_ = s;
    stateTime_ = 0;
    switch (s) {
    case State::Logo: audio_.play(Sfx::LogoSting, 0.9f); break;
    case State::Menu:
        stopLoops();
        hTv_ = audio_.play(Sfx::TvCrowd, 0.12f, -0.3f, true);
        hHum_ = audio_.play(Sfx::Hum, 0.25f, 0, true);
        break;
    case State::Jumpscare:
        stopLoops();
        audio_.play(Sfx::Scream, 1.0f);
        break;
    case State::GameOver: hStatic_ = audio_.play(Sfx::Static, 0.4f, 0, true); break;
    case State::SixAM:
        stopLoops();
        audio_.play(Sfx::Chime, 0.9f);
        break;
    default: break;
    }
}

void Game::debugStartNight(int n) { startNight(n); setState(State::Playing); startLoops(); }

void Game::startNight(int n) {
    night_ = std::clamp(n, 1, 5);
    negron_.reset(aiLevelForNight(night_), 1000u + night_ * 77u + uint32_t(time_ * 1000));
    nightTime_ = 0;
    power_ = 100;
    powerOut_ = false;
    powerOutTime_ = 0;
    doorClosed_ = false;
    doorAnim_ = 0;
    lightOn_ = false;
    camUp_ = false;
    camAnim_ = 0;
    cam_ = CamId::LivingRoom;
    tvOn_ = false;
    beerLeft_ = beerForNight(night_);
    beerCooldown_ = 0;
    beerDropT_ = -1;
    yaw_ = 0;
    yawVel_ = 0;
    toast_.clear();
    ptrs_.clear();
}

void Game::stopLoops() {
    for (int* h : {&hHum_, &hStatic_, &hBuzz_, &hTv_, &hFridge_}) {
        if (*h >= 0) audio_.stop(*h);
        *h = -1;
    }
}

void Game::startLoops() {
    stopLoops();
    hHum_ = audio_.play(Sfx::Hum, 0.35f, 0, true);
}

void Game::updateLoops() {
    auto ensure = [&](int& h, bool want, Sfx s, float vol, float pan) {
        if (want && h < 0) h = audio_.play(s, vol, pan, true);
        else if (!want && h >= 0) { audio_.stop(h); h = -1; }
        else if (want) audio_.setVolume(h, vol);
    };
    bool playing = state_ == State::Playing && !powerOut_;
    ensure(hStatic_, playing && camUp_, Sfx::Static, 0.08f + camGlitch_ * 0.5f, 0);
    ensure(hBuzz_, playing && lightOn_, Sfx::LightBuzz, 0.18f, -0.6f);
    float tvVol = (camUp_ && cam_ == CamId::LivingRoom) ? 0.35f : 0.05f;
    ensure(hTv_, playing && tvOn_, Sfx::TvCrowd, tvVol, 0);
    bool fridge = playing && camUp_ && cam_ == CamId::Kitchen && negron_.loc() == NegronLoc::Kitchen;
    ensure(hFridge_, fridge, Sfx::FridgeHum, 0.3f, 0);
    if (hHum_ >= 0 && state_ == State::Playing) audio_.setVolume(hHum_, powerOut_ ? 0.0f : 0.3f);
}

// ------------------------------------------------------------------ input

void Game::pointerDown(float x, float y, int id) {
    ptrs_.push_back({id, x, y, x, y, false, false});
    if (state_ == State::Playing) {
        // buttons react on press (door must be instant!)
        if (btnCam_.contains(x, y)) { toggleCamera(); ptrs_.back().dragging = true; return; }
        if (!camUp_ && !powerOut_ && yaw_ < -0.3f) {
            if (btnDoor_.contains(x, y)) { toggleDoor(); ptrs_.back().dragging = true; return; }
            if (btnLight_.contains(x, y)) { setLight(true); ptrs_.back().lightHold = true; ptrs_.back().dragging = true; return; }
        }
        if (camUp_ && camAnim_ > 0.9f) {
            for (int i = 0; i < 3; ++i)
                if (btnCams_[i].contains(x, y)) { switchCam(CamId(i)); ptrs_.back().dragging = true; return; }
            if (cam_ != CamId::Corridor && btnBeer_.contains(x, y)) { sendBeer(); ptrs_.back().dragging = true; return; }
            if (cam_ == CamId::LivingRoom && btnTv_.contains(x, y)) { toggleTv(); ptrs_.back().dragging = true; return; }
        }
    }
}

void Game::pointerMove(float x, float y, int id) {
    for (auto& p : ptrs_)
        if (p.id == id) {
            float dx = x - p.x;
            if (state_ == State::Playing && !camUp_ && !p.dragging) yaw_ -= dx * 0.007f;
            p.x = x; p.y = y;
        }
    yaw_ = clampf(yaw_, -0.78f, 0.78f);
}

void Game::pointerUp(float x, float y, int id) {
    for (size_t i = 0; i < ptrs_.size(); ++i)
        if (ptrs_[i].id == id) {
            Ptr p = ptrs_[i];
            ptrs_.erase(ptrs_.begin() + i);
            if (p.lightHold) setLight(false);
            float moved = std::fabs(x - p.startX) + std::fabs(y - p.startY);
            if (!p.dragging && moved < 10) tap(x, y);
            return;
        }
}

void Game::tap(float x, float y) {
    switch (state_) {
    case State::Logo:
        if (stateTime_ > 1.0f) setState(State::Warning);
        break;
    case State::Warning:
        if (stateTime_ > 0.8f) setState(State::Menu);
        break;
    case State::Menu:
        if (btnNew_.contains(x, y)) {
            audio_.play(Sfx::Click);
            savedNight_ = 1;
            writeSave();
            stopLoops();
            startNight(1);
            setState(State::NightIntro);
        } else if (btnContinue_.contains(x, y)) {
            audio_.play(Sfx::Click);
            stopLoops();
            startNight(savedNight_);
            setState(State::NightIntro);
        }
        break;
    case State::NightIntro:
        if (stateTime_ > 1.0f) { setState(State::Playing); startLoops(); }
        break;
    case State::GameOver:
        if (stateTime_ > 1.5f) setState(State::Menu);
        break;
    case State::SixAM:
        if (stateTime_ > 2.5f) stateTime_ = 100;  // skip
        break;
    case State::AlphaEnd:
        if (stateTime_ > 2.0f) setState(State::Menu);
        break;
    case State::Paused:
        state_ = prevState_;
        if (state_ == State::Playing) startLoops();
        break;
    default: break;
    }
}

void Game::key(Key k, bool down) {
    if (k == Key::Left) keyLeft_ = down;
    if (k == Key::Right) keyRight_ = down;
    if (!down) {
        if (k == Key::Light && state_ == State::Playing) setLight(false);
        return;
    }
    if (state_ == State::Playing) {
        switch (k) {
        case Key::Door: if (!powerOut_ && !camUp_) toggleDoor(); break;
        case Key::Light: if (!powerOut_ && !camUp_) setLight(true); break;
        case Key::Camera: toggleCamera(); break;
        case Key::Beer: if (camUp_) sendBeer(); break;
        case Key::Tv: if (camUp_) toggleTv(); break;
        case Key::Cam1: if (camUp_) switchCam(CamId::LivingRoom); break;
        case Key::Cam2: if (camUp_) switchCam(CamId::Kitchen); break;
        case Key::Cam3: if (camUp_) switchCam(CamId::Corridor); break;
        case Key::Back: onPause(); break;
        default: break;
        }
        return;
    }
    if (k == Key::Back && state_ == State::Menu) { quit_ = true; return; }
    if (k == Key::Enter || k == Key::Back) {
        if (state_ == State::Menu) tap(btnContinue_.x + 5, btnContinue_.y + 5);
        else tap(0, 0);
    }
}

void Game::onPause() {
    if (state_ == State::Playing) {
        stopLoops();
        setState(State::Paused);
    }
}

// ------------------------------------------------------------------ actions

void Game::toggleCamera() {
    if (powerOut_) return;
    camUp_ = !camUp_;
    audio_.play(Sfx::MonitorUp, 0.5f);
    if (camUp_) { setLight(false); camGlitch_ = 0.4f; }
}

void Game::toggleDoor() {
    doorClosed_ = !doorClosed_;
    audio_.play(doorClosed_ ? Sfx::DoorClose : Sfx::DoorOpen, 0.9f, -0.7f);
}

void Game::setLight(bool on) {
    if (on && (powerOut_ || camUp_)) return;
    if (on && !lightOn_) {
        lightHoldTime_ = 0;
        if (negron_.loc() == NegronLoc::Door && !doorClosed_) audio_.play(Sfx::Burp, 0.5f, -0.7f, false, 0.75f);
    }
    lightOn_ = on;
}

void Game::sendBeer() {
    if (beerCooldown_ > 0) { toast_ = "Пивопровод заряжается..."; toastTime_ = 1.5f; return; }
    if (beerLeft_ <= 0) { toast_ = "Пиво кончилось!"; toastTime_ = 2.0f; return; }
    beerLeft_--;
    power_ -= 1.0f;
    beerCooldown_ = 3.0f;
    beerDropT_ = 0;
    audio_.play(Sfx::CanOpen, 0.8f);
    NegronLoc before = negron_.loc();
    bool drank = negron_.deliverBeer();
    if (drank && before == NegronLoc::Kitchen) { toast_ = "Услышал \"пшшш\"! Вернулся на диван."; toastTime_ = 2.5f; }
    else if (drank) { toast_ = "Негрон пьёт. Буль-буль."; toastTime_ = 2.0f; }
    else if (before == NegronLoc::Kitchen) { toast_ = "Не услышал... Банка пропала зря."; toastTime_ = 2.5f; }
    else { toast_ = "Его нет на диване. Банка пропала зря."; toastTime_ = 2.5f; }
    if (drank) audio_.play(Sfx::Glug, cam_ == CamId::LivingRoom ? 0.6f : 0.25f, 0, false, 1.0f);
}

void Game::toggleTv() {
    tvOn_ = !tvOn_;
    audio_.play(Sfx::Click, 0.6f);
}

void Game::switchCam(CamId c) {
    if (c == cam_) return;
    cam_ = c;
    camGlitch_ = 0.35f;
    audio_.play(Sfx::CamBlip, 0.5f);
}

void Game::triggerJumpscare() {
    camUp_ = false;
    lightOn_ = false;
    jumpscareDark_ = powerOut_;
    if (powerOut_) deathReason_ = "Свет кончился. Негрон пришёл в темноте.";
    else if (negron_.rampage()) deathReason_ = "Пьяный Негрон прорвался в офис.";
    else deathReason_ = "Негрон пришёл за пивом. Пива не было.";
    setState(State::Jumpscare);
}

void Game::endNightWin() {
    if (night_ >= savedNight_) savedNight_ = std::min(5, night_ + 1);
    writeSave();
    setState(State::SixAM);
}

// ------------------------------------------------------------------ update

void Game::update(float dt) {
    dt = std::min(dt, 0.1f);
    time_ += dt;
    stateTime_ += dt;

    switch (state_) {
    case State::Logo:
        if (stateTime_ > 5.0f) setState(State::Warning);
        break;
    case State::Warning:
        if (stateTime_ > 3.5f) setState(State::Menu);
        break;
    case State::NightIntro:
        if (stateTime_ > 4.0f) { setState(State::Playing); startLoops(); }
        break;
    case State::Playing: updatePlaying(dt); break;
    case State::Jumpscare:
        if (stateTime_ > 1.6f) setState(State::GameOver);
        break;
    case State::GameOver:
        if (stateTime_ > 8.0f) setState(State::Menu);
        break;
    case State::SixAM:
        if (stateTime_ > 7.0f) {
            if (night_ >= 5) setState(State::AlphaEnd);
            else { startNight(night_ + 1); setState(State::NightIntro); }
        }
        break;
    default: break;
    }
    updateLoops();
}

void Game::updatePlaying(float dt) {
    nightTime_ += dt;
    if (nightTime_ >= HOUR_SECONDS * 6) { endNightWin(); return; }

    // look around
    if (!camUp_) {
        float target = 0;
        if (keyLeft_) target -= 1.6f;
        if (keyRight_) target += 1.6f;
        for (auto& p : ptrs_)
            if (!p.dragging && std::fabs(p.x - p.startX) < 6) {  // finger resting near a screen edge
                if (p.x < 36) target -= 1.4f;
                if (p.x > Renderer::W - 36) target += 1.4f;
            }
        yaw_ = clampf(yaw_ + target * dt, -0.78f, 0.78f);
    }

    camAnim_ = clampf(camAnim_ + (camUp_ ? dt : -dt) * 5.0f, 0, 1);
    doorAnim_ = clampf(doorAnim_ + (doorClosed_ ? dt : -dt) * 4.0f, 0, 1);
    camGlitch_ = std::max(0.0f, camGlitch_ - dt);
    beerCooldown_ = std::max(0.0f, beerCooldown_ - dt);
    if (beerDropT_ >= 0) { beerDropT_ += dt; if (beerDropT_ > 1.5f) beerDropT_ = -1; }
    toastTime_ = std::max(0.0f, toastTime_ - dt);
    if (lightOn_) lightHoldTime_ += dt;  // the light is a hold button (finger or key)
    lampFlicker_ = (rng_.f01() > 0.985f) ? 0.4f : 1.0f;

    if (powerOut_) {
        powerOutTime_ += dt;
        if (powerOutTime_ >= powerOutAttackAt_) triggerJumpscare();
        return;
    }

    // power drain
    float drain = 0.09f + night_ * 0.03f;
    if (doorClosed_) drain += 0.35f;
    if (lightOn_) drain += 0.22f;
    if (camUp_) drain += 0.08f;
    if (tvOn_) drain += 0.12f;
    power_ -= drain * dt;
    if (power_ <= 0) {
        power_ = 0;
        powerOut_ = true;
        powerOutTime_ = 0;
        powerOutAttackAt_ = rng_.range(6.0f, 13.0f);
        camUp_ = false;
        lightOn_ = false;
        tvOn_ = false;
        if (doorClosed_) { doorClosed_ = false; audio_.play(Sfx::DoorOpen, 0.9f, -0.7f); }
        audio_.play(Sfx::PowerDown, 0.9f);
        negron_.forcePowerOutAttack();
        return;
    }

    negron_.update(dt, doorClosed_ && doorAnim_ > 0.9f, tvOn_);
    const NegronEvents& e = negron_.events();
    NegronLoc loc = negron_.loc();
    float roomPan = loc == NegronLoc::Kitchen ? 0.4f : (loc == NegronLoc::Sofa ? 0.2f : -0.6f);
    if (e.gotUp) audio_.play(Sfx::CouchCreak, 0.35f, 0.2f);
    if (e.burp) audio_.play(Sfx::Burp, e.rampageStart ? 0.8f : 0.3f, roomPan, false, e.rampageStart ? 1.25f : 1.0f);
    if (e.footstep) audio_.play(Sfx::Footstep, e.footstepVolume, -0.5f, false, negron_.rampage() ? 1.2f : 1.0f);
    if (e.reachedDoor) audio_.play(Sfx::Burp, 0.55f, -0.8f, false, 0.8f);
    if (e.bang) audio_.play(Sfx::DoorBang, 1.0f, -0.7f, false, 0.9f + rng_.f01() * 0.2f);
    if (e.movedRoom && camUp_) camGlitch_ = std::max(camGlitch_, 0.7f);
    if (e.rampageStart) { toast_ = "!!! НЕГРОН ПЕРЕПИЛ И БУЯНИТ !!!"; toastTime_ = 3.0f; }
    if (e.passedOut) { toast_ = "Негрон вырубился на диване. Хр-р-р..."; toastTime_ = 3.0f; }
    else if (e.leftDoor) { toast_ = "Негрон ушёл обратно на диван."; toastTime_ = 2.5f; }
    if (e.attack) triggerJumpscare();
}

// ------------------------------------------------------------------ rendering

std::string Game::clockText() const {
    int hour = int(nightTime_ / HOUR_SECONDS);
    return std::string(hour == 0 ? "12" : std::to_string(hour)) + " AM";
}

int Game::usageBars() const {
    return 1 + (doorClosed_ ? 1 : 0) + (lightOn_ ? 1 : 0) + (camUp_ ? 1 : 0) + (tvOn_ ? 1 : 0);
}

void Game::drawButton(const Button& b, const std::string& label, Vec3 col, bool active, bool enabled) {
    Vec3 bg = active ? col * 0.55f : Vec3(0.06f, 0.06f, 0.07f);
    renderer_.rect(b.x, b.y, b.w, b.h, bg, enabled ? 0.85f : 0.4f);
    renderer_.rectOutline(b.x, b.y, b.w, b.h, enabled ? col : DIM);
    renderer_.textCentered(b.x + b.w / 2, b.y + (b.h - 12) / 2, label, enabled ? (active ? WHITE : col) : DIM);
}

void Game::renderSms() {
    float t = nightTime_ - 2.0f;
    if (night_ != 1 || t < 0 || t >= SMS_COUNT * SMS_TIME) return;
    int i = int(t / SMS_TIME);
    float local = t - i * SMS_TIME;
    float a = clampf(std::min(local, SMS_TIME - local) * 4.0f, 0, 1);
    Renderer& r = renderer_;
    int w = r.textWidth(SMS[i]) + 16;
    int x = (Renderer::W - w) / 2;
    r.rect(x, 26, w, 34, Vec3(0.02f, 0.05f, 0.03f), 0.8f * a);
    r.rectOutline(x, 26, w, 34, GREEN * a);
    r.text(x + 8, 29, "СМС от Деда (" + std::to_string(i + 1) + "/" + std::to_string(SMS_COUNT) + ")", GREEN * a, 1, false);
    r.text(x + 8, 44, SMS[i], WHITE * a);
}

void Game::renderHudOffice() {
    Renderer& r = renderer_;
    r.text(8, 6, "НОЧЬ " + std::to_string(night_), WHITE);
    r.text(Renderer::W - 8 - r.textWidth(clockText(), 2), 6, clockText(), WHITE, 2);

    // power
    std::string pw = "ЭНЕРГИЯ: " + std::to_string(int(std::ceil(power_))) + "%";
    r.text(8, Renderer::H - 40, pw, power_ < 20 ? RED : WHITE);
    r.text(8, Renderer::H - 24, "РАСХОД:", WHITE);
    int bars = usageBars();
    for (int i = 0; i < bars; ++i) {
        Vec3 c = i < 2 ? GREEN : (i < 3 ? YELLOW : RED);
        r.rect(60 + i * 10, Renderer::H - 23, 8, 11, c);
    }
    std::string beer = "ПИВО: " + std::to_string(beerLeft_);
    r.text(Renderer::W - 8 - r.textWidth(beer), Renderer::H - 24, beer, YELLOW);

    if (!powerOut_) {
        drawButton(btnCam_, "^  КАМЕРЫ  ^", WHITE, false);
        float a = clampf((-yaw_ - 0.3f) * 5.0f, 0, 1);
        if (a > 0) {
            drawButton(btnDoor_, doorClosed_ ? "ОТКРЫТЬ" : "ДВЕРЬ", RED, doorClosed_);
            drawButton(btnLight_, "СВЕТ", Vec3(0.95f, 0.85f, 0.5f), lightOn_);
        } else {
            r.text(8, 112, "< дверь", DIM);
        }
    }
}

void Game::renderHudCamera() {
    Renderer& r = renderer_;
    int ci = int(cam_);
    // REC + name
    if (int(time_ * 2) % 2 == 0) r.rect(10, 10, 8, 8, RED);
    r.text(24, 8, "CAM " + std::to_string(ci + 1) + " - " + CAM_NAMES[ci], WHITE);
    r.text(Renderer::W - 8 - r.textWidth(clockText(), 2), 6, clockText(), WHITE, 2);
    r.rectOutline(4, 4, Renderer::W - 8, Renderer::H - 8, WHITE * 0.5f);

    // map
    r.rect(344, 104, 136, 126, Vec3(0, 0, 0), 0.35f);
    r.text(350, 92, "КАРТА", DIM);
    r.line(381, 138, 413, 180, WHITE * 0.6f);
    r.line(445, 138, 413, 180, WHITE * 0.6f);
    r.line(413, 190, 413, 206, WHITE * 0.6f);
    for (int i = 0; i < 3; ++i) {
        bool sel = i == ci;
        drawButton(btnCams_[i], "CAM " + std::to_string(i + 1), sel ? GREEN : WHITE, sel);
    }
    r.rect(390, 206, 46, 18, Vec3(0.2f, 0.05f, 0.05f), 0.9f);
    r.textCentered(413, 209, "ВЫ", RED);

    // beer pipe controls
    if (cam_ != CamId::Corridor) {
        std::string lbl = beerCooldown_ > 0 ? "ЗАРЯДКА..." : ("ПОДАТЬ ПИВО (" + std::to_string(beerLeft_) + ")");
        drawButton(btnBeer_, lbl, YELLOW, false, beerLeft_ > 0 && beerCooldown_ <= 0);
    }
    if (cam_ == CamId::LivingRoom) drawButton(btnTv_, tvOn_ ? "ТВ: ФУТБОЛ ВКЛ" : "ТВ: ВЫКЛ", GREEN, tvOn_);

    // smart-can telemetry when he is on the couch
    if (cam_ == CamId::LivingRoom && negron_.loc() == NegronLoc::Sofa) {
        r.text(8, 150, "ПИВО В БАНКЕ", WHITE);
        float can = clampf(1.0f - negron_.thirst() / 100.0f, 0, 1);
        r.rect(112, 152, 70, 8, Vec3(0.1f, 0.1f, 0.1f));
        r.rect(112, 152, int(70 * can), 8, can < 0.25f ? RED : YELLOW);
        r.text(8, 166, "ГРАДУС", WHITE);
        float dr = clampf(negron_.drunk() / 100.0f, 0, 1);
        r.rect(112, 168, 70, 8, Vec3(0.1f, 0.1f, 0.1f));
        r.rect(112, 168, int(70 * dr), 8, dr > 0.75f ? RED : Vec3(0.8f, 0.4f, 0.1f));
        if (negron_.asleep()) r.text(8, 180, "СПИТ: Хр-р-р...", GREEN);
    }
    if (cam_ == CamId::Kitchen && negron_.loc() == NegronLoc::Kitchen)
        r.text(8, 180, "Ищет пиво в холодильнике...", YELLOW);

    drawButton(btnCam_, "v  ОФИС  v", WHITE, false);
}

void Game::renderMenu() {
    Renderer& r = renderer_;
    world_.renderMenuBackground(r, time_);
    r.tint(Vec3(1.0f, 0.85f, 0.8f), 0.3f);
    r.noise(0.07f, uint32_t(time_ * 60));
    r.scanlines(0.15f);
    r.vignette(0.9f);
    // title
    float jit = (std::sin(time_ * 37) > 0.97f) ? 2.0f : 0.0f;
    r.text(30 + int(jit), 26, "5 NIGHTS", WHITE, 3);
    r.text(30, 62, "IN DED", RED, 3);
    r.text(32, 100, "Пять ночей у Деда", DIM);
    drawButton(btnNew_, "НОВАЯ ИГРА", WHITE, false);
    drawButton(btnContinue_, "ПРОДОЛЖИТЬ: НОЧЬ " + std::to_string(savedNight_), WHITE, false);
    r.text(8, Renderer::H - 16, std::string("Dead Ded Entertainment - ") + VERSION, DIM);
}

void Game::render() {
    Renderer& r = renderer_;
    switch (state_) {
    case State::Logo: {
        world_.renderLogo(r, stateTime_);
        int x = Renderer::W / 2 - r.textWidth("DEAD DED", 4) / 2;
        r.text(x, 176, "DEAD DED", Vec3(0.8f, 0.05f, 0.04f), 4);
        // blood drips
        for (int i = 0; i < 14; ++i) {
            int dx = x + 6 + int((i * 97) % 220);
            float len = clampf(stateTime_ * (6 + (i * 13) % 11) - 3.0f, 0, 14 + (i * 7) % 18);
            r.rect(dx, 210, 2, int(len), Vec3(0.6f, 0.03f, 0.03f));
        }
        r.textCentered(Renderer::W / 2, 228, "ENTERTAINMENT", Vec3(0.88f, 0.84f, 0.75f), 2);
        r.noise(0.05f, uint32_t(stateTime_ * 60));
        float fade = clampf(std::min(stateTime_ / 0.8f, (5.0f - stateTime_) / 0.8f), 0, 1);
        r.brightness(fade);
        break;
    }
    case State::Warning: {
        r.clear(Vec3(0, 0, 0));
        float a = clampf(std::min(stateTime_ * 2, (3.5f - stateTime_) * 2), 0, 1);
        r.textCentered(Renderer::W / 2, 80, "ВНИМАНИЕ!", RED * a, 2);
        r.textCentered(Renderer::W / 2, 120, "В игре есть громкие звуки и скримеры.", WHITE * a);
        r.textCentered(Renderer::W / 2, 136, "Играйте в наушниках. Слушайте шаги.", WHITE * a);
        r.textCentered(Renderer::W / 2, 180, std::string("АЛЬФА-ВЕРСИЯ ") + VERSION, DIM * a);
        break;
    }
    case State::Menu: renderMenu(); break;
    case State::NightIntro: {
        r.clear(Vec3(0, 0, 0));
        float a = clampf(std::min(stateTime_ * 1.5f, (4.0f - stateTime_) * 1.5f), 0, 1);
        r.textCentered(Renderer::W / 2, 90, "12:00 AM", WHITE * a, 3);
        r.textCentered(Renderer::W / 2, 140, "НОЧЬ " + std::to_string(night_), WHITE * a, 2);
        const char* sub[] = {"Дед уехал на дачу. Негрон остался.", "Негрон стал пить больше.",
                             "Пиво дорожает. Банок меньше.", "Негрон не спит.", "Последняя ночь альфы."};
        r.textCentered(Renderer::W / 2, 180, sub[night_ - 1], DIM * a);
        break;
    }
    case State::Paused: {
        r.clear(Vec3(0, 0, 0));
        r.textCentered(Renderer::W / 2, 110, "ПАУЗА", WHITE, 3);
        r.textCentered(Renderer::W / 2, 160, "Нажми, чтобы продолжить", DIM);
        break;
    }
    case State::Playing: {
        bool showCam = camAnim_ >= 1.0f;
        if (showCam) {
            RoomView v;
            v.t = time_;
            v.loc = negron_.loc();
            v.progress = negron_.progress();
            v.stateTime = negron_.stateTime();
            v.drinkAnim = negron_.drinkAnim();
            v.asleep = negron_.asleep();
            v.rampage = negron_.rampage();
            v.tvOn = tvOn_;
            v.beerDrop = beerDropT_;
            world_.renderCamera(r, cam_, v);
            r.tint(Vec3(0.92f, 1.05f, 0.95f), 0.25f);
            r.noise(0.07f + camGlitch_ * 1.2f, uint32_t(time_ * 60));
            r.scanlines(0.18f);
            if (camGlitch_ > 0.3f) r.shake(int((rng_.f01() - 0.5f) * 20), 0);
            r.vignette(0.35f);
            renderHudCamera();
        } else {
            OfficeView ov;
            ov.t = time_;
            ov.yaw = yaw_;
            ov.doorClosed = doorAnim_;
            ov.lightOn = lightOn_;
            ov.powerOut = powerOut_;
            ov.lampFlicker = lampFlicker_;
            ov.negronAtDoor = negron_.loc() == NegronLoc::Door;
            ov.negronRampage = negron_.rampage();
            ov.eyesInDark = powerOut_ && powerOutTime_ > powerOutAttackAt_ - 3.5f;
            world_.renderOffice(r, ov);
            r.vignette(0.7f);
            if (camAnim_ > 0) {  // tablet sliding up/down
                int h = int(Renderer::H * camAnim_);
                r.rect(0, Renderer::H - h, Renderer::W, h, Vec3(0.05f, 0.06f, 0.05f));
                r.rectOutline(6, Renderer::H - h + 6, Renderer::W - 12, std::max(0, h - 12), DIM);
            } else {
                renderHudOffice();
            }
        }
        renderSms();
        if (toastTime_ > 0) {
            float a = clampf(toastTime_ * 3, 0, 1);
            int w = r.textWidth(toast_) + 12;
            r.rect((Renderer::W - w) / 2, 70, w, 18, Vec3(0, 0, 0), 0.7f * a);
            r.textCentered(Renderer::W / 2, 73, toast_, YELLOW * a);
        }
        break;
    }
    case State::Jumpscare: {
        world_.renderJumpscare(r, stateTime_, jumpscareDark_);
        if (int(stateTime_ * 20) % 3 == 0) r.tint(Vec3(1.6f, 0.4f, 0.4f), 0.2f);
        r.shake(int(std::sin(stateTime_ * 90) * 8), int(std::cos(stateTime_ * 70) * 6));
        r.noise(0.2f, uint32_t(stateTime_ * 60));
        break;
    }
    case State::GameOver: {
        r.clear(Vec3(0.02f, 0.02f, 0.02f));
        r.noise(0.5f * clampf(1.5f - stateTime_ * 0.5f, 0.2f, 1.5f), uint32_t(stateTime_ * 60));
        r.scanlines(0.3f);
        float a = clampf((stateTime_ - 0.8f) * 1.5f, 0, 1);
        r.textCentered(Renderer::W / 2, 80, "GAME OVER", RED * a, 3);
        r.textCentered(Renderer::W / 2, 140, deathReason_, WHITE * a);
        r.textCentered(Renderer::W / 2, 160, "Ночь " + std::to_string(night_) + ", " + clockText(), DIM * a);
        if (stateTime_ > 1.5f) r.textCentered(Renderer::W / 2, 220, "Нажми, чтобы вернуться в меню", DIM);
        break;
    }
    case State::SixAM: {
        r.clear(Vec3(0, 0, 0));
        float k = smooth01((stateTime_ - 0.8f) / 1.2f);
        int y = int(lerpf(0, -40, k));
        r.textCentered(Renderer::W / 2 - 30, 100, "5", WHITE * (1 - k), 4);
        r.textCentered(Renderer::W / 2 - 30, 100 + 40 + y, "6", WHITE * k, 4);
        r.text(Renderer::W / 2 - 10, 100, "AM", WHITE, 4);
        r.rect(0, 0, Renderer::W, 98, Vec3(0, 0, 0));
        r.rect(0, 150, Renderer::W, 40, Vec3(0, 0, 0));
        if (stateTime_ > 2.0f) r.textCentered(Renderer::W / 2, 200, "НОЧЬ " + std::to_string(night_) + " ПРОЙДЕНА", GREEN);
        if (stateTime_ > 3.0f) r.textCentered(Renderer::W / 2, 222, "Негрон уснул на диване. До следующей ночи.", DIM);
        break;
    }
    case State::AlphaEnd: {
        world_.renderMenuBackground(r, time_);
        r.brightness(0.35f);
        r.vignette(1.0f);
        r.textCentered(Renderer::W / 2, 50, "ТЫ ПЕРЕЖИЛ 5 НОЧЕЙ", GREEN, 2);
        r.textCentered(Renderer::W / 2, 100, "Дед вернулся с дачи. Негрон всё ещё на диване.", WHITE);
        r.textCentered(Renderer::W / 2, 125, "Спасибо за игру в альфа-версию!", WHITE);
        r.textCentered(Renderer::W / 2, 150, "Скоро: новые персонажи.", YELLOW);
        r.textCentered(Renderer::W / 2, 220, "Dead Ded Entertainment", RED, 2);
        break;
    }
    }
}
