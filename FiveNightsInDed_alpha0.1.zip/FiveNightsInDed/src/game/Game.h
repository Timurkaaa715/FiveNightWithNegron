#pragma once
#include <string>
#include <vector>
#include "../engine/Audio.h"
#include "../engine/Renderer.h"
#include "Negron.h"
#include "World.h"

// "5 Nights in Ded" — alpha 0.1 by Dead Ded Entertainment.
// Platform-independent game core. The platform layer (SDL2 on Android/iOS/desktop,
// or the headless test runner) feeds input + time and presents Renderer::resolve().

enum class Key { Left, Right, Door, Light, Camera, Beer, Tv, Cam1, Cam2, Cam3, Enter, Back };

class Game {
public:
    static constexpr const char* VERSION = "alpha 0.1";

    void init(const std::string& savePath);
    void update(float dt);
    void render();

    // pointer coordinates in framebuffer pixels (0..Renderer::W, 0..Renderer::H)
    void pointerDown(float x, float y, int id);
    void pointerMove(float x, float y, int id);
    void pointerUp(float x, float y, int id);
    void key(Key k, bool down);
    void onPause();   // app sent to background
    bool wantsQuit() const { return quit_; }

    Renderer& renderer() { return renderer_; }
    Audio& audio() { return audio_; }

    // --- hooks for the automated test runner ---
    enum class State { Logo, Warning, Menu, NightIntro, Playing, Jumpscare, GameOver, SixAM, AlphaEnd, Paused };
    State state() const { return state_; }
    void debugStartNight(int n);
    NegronAI& debugNegron() { return negron_; }
    bool cameraUp() const { return camUp_; }
    bool doorClosed() const { return doorClosed_; }
    float power() const { return power_; }
    float nightTime() const { return nightTime_; }
    int night() const { return night_; }
    int beerLeft() const { return beerLeft_; }
    CamId currentCam() const { return cam_; }
    bool tvOn() const { return tvOn_; }
    float yaw() const { return yaw_; }

    // Night tuning (exposed for balancing tests)
    static constexpr float HOUR_SECONDS = 45.0f;  // 6 hours -> 4.5 minutes per night
    static int aiLevelForNight(int n);
    static int beerForNight(int n);

private:
    struct Button {
        int x, y, w, h;
        bool contains(float px, float py) const { return px >= x && px < x + w && py >= y && py < y + h; }
    };

    void setState(State s);
    void startNight(int n);
    void endNightWin();
    void triggerJumpscare();
    void updatePlaying(float dt);
    void tap(float x, float y);
    void toggleCamera();
    void toggleDoor();
    void setLight(bool on);
    void sendBeer();
    void toggleTv();
    void switchCam(CamId c);
    void startLoops();
    void stopLoops();
    void updateLoops();

    void drawButton(const Button& b, const std::string& label, Vec3 col, bool active, bool enabled = true);
    void renderHudOffice();
    void renderHudCamera();
    void renderMenu();
    void renderSms();
    std::string clockText() const;
    int usageBars() const;

    void loadSave();
    void writeSave();

    Renderer renderer_;
    Audio audio_;
    World world_;
    NegronAI negron_;
    Rng rng_{12345};
    std::string savePath_;
    bool quit_ = false;

    State state_ = State::Logo;
    State prevState_ = State::Menu;
    float stateTime_ = 0;
    float time_ = 0;

    // progress
    int savedNight_ = 1;
    int night_ = 1;

    // night state
    float nightTime_ = 0;
    float power_ = 100;
    bool powerOut_ = false;
    float powerOutTime_ = 0;
    float powerOutAttackAt_ = 0;
    bool doorClosed_ = false;
    float doorAnim_ = 0;
    bool lightOn_ = false;
    bool camUp_ = false;
    float camAnim_ = 0;
    CamId cam_ = CamId::LivingRoom;
    float camGlitch_ = 0;
    bool tvOn_ = false;
    int beerLeft_ = 12;
    float beerCooldown_ = 0;
    float beerDropT_ = -1;
    std::string toast_;
    float toastTime_ = 0;
    float yaw_ = 0;
    float yawVel_ = 0;
    bool keyLeft_ = false, keyRight_ = false;
    float lampFlicker_ = 1;
    float lightHoldTime_ = 0;
    bool jumpscareDark_ = false;
    std::string deathReason_;

    // pointer tracking (drag to look around)
    struct Ptr { int id; float x, y, startX, startY; bool dragging; bool lightHold; };
    std::vector<Ptr> ptrs_;

    // audio loop handles
    int hHum_ = -1, hStatic_ = -1, hBuzz_ = -1, hTv_ = -1, hFridge_ = -1;

    // UI buttons (framebuffer coordinates)
    const Button btnCam_{160, 246, 160, 22};
    const Button btnDoor_{8, 92, 74, 34};
    const Button btnLight_{8, 132, 74, 34};
    const Button btnBeer_{8, 196, 144, 26};
    const Button btnTv_{8, 226, 144, 18};
    const Button btnCams_[3] = {{352, 116, 58, 22}, {416, 116, 58, 22}, {384, 168, 58, 22}};
    const Button btnNew_{30, 150, 176, 24};
    const Button btnContinue_{30, 182, 176, 24};
};
