#pragma once
#include "../engine/Renderer.h"
#include "../engine/Textures.h"
#include "Negron.h"

struct OfficeView {
    float t = 0;
    float yaw = 0;          // radians, negative = look left (door)
    float doorClosed = 0;   // 0 open .. 1 closed (animated)
    bool lightOn = false;
    bool powerOut = false;
    bool negronAtDoor = false;
    bool negronRampage = false;
    bool eyesInDark = false; // power-out stare
    float lampFlicker = 1;
};

struct RoomView {
    float t = 0;
    NegronLoc loc = NegronLoc::Sofa;
    float progress = 0;
    float stateTime = 0;
    float drinkAnim = 0;
    bool asleep = false;
    bool rampage = false;
    bool tvOn = false;
    float beerDrop = -1;   // seconds since a can was dropped by the beer pipe (<0 none)
};

enum class CamId { LivingRoom = 0, Kitchen = 1, Corridor = 2, Count = 3 };

class World {
public:
    void build(Renderer& r);
    const TextureSet& tex() const { return tx_; }

    void renderOffice(Renderer& r, const OfficeView& v);
    void renderCamera(Renderer& r, CamId cam, const RoomView& v);
    void renderJumpscare(Renderer& r, float t, bool dark);
    void renderLogo(Renderer& r, float t);
    void renderMenuBackground(Renderer& r, float t);

private:
    void buildOffice();
    void buildLivingRoom();
    void buildKitchen();
    void buildCorridor();
    void buildLogo();

    TextureSet tx_;
    NegronModel negron_;
    Mesh office_, officeShutter_, officeFanBlades_, officeHallway_;
    Mesh living_, tvScreenOn_, tvScreenOff_, beerCan_;
    Mesh kitchen_, fridgeDoor_, fridgeInside_;
    Mesh corridor_;
    Mesh skull_, logoBackdrop_;
};
