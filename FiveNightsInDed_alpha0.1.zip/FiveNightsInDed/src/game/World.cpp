#include "World.h"

using namespace build;

namespace {

// --- wall helpers (normal direction given by sign) ---
void wallX(Mesh& m, float x, float z0, float z1, float y0, float y1, int sign, const Mat& mat, int sub = 4) {
    if (sign > 0) quad(m, {x, y0, z1}, {x, y0, z0}, {x, y1, z0}, {x, y1, z1}, mat, sub);
    else quad(m, {x, y0, z0}, {x, y0, z1}, {x, y1, z1}, {x, y1, z0}, mat, sub);
}
void wallZ(Mesh& m, float z, float x0, float x1, float y0, float y1, int sign, const Mat& mat, int sub = 4) {
    if (sign > 0) quad(m, {x0, y0, z}, {x1, y0, z}, {x1, y1, z}, {x0, y1, z}, mat, sub);
    else quad(m, {x1, y0, z}, {x0, y0, z}, {x0, y1, z}, {x1, y1, z}, mat, sub);
}
void planeY(Mesh& m, float y, float x0, float x1, float z0, float z1, int sign, const Mat& mat, int sub = 6) {
    if (sign > 0) quad(m, {x0, y, z1}, {x1, y, z1}, {x1, y, z0}, {x0, y, z0}, mat, sub);
    else quad(m, {x0, y, z0}, {x1, y, z0}, {x1, y, z1}, {x0, y, z1}, mat, sub);
}
void room(Mesh& m, float x0, float x1, float z0, float z1, float h, const Mat& wall, const Mat& floor, const Mat& ceil) {
    planeY(m, 0, x0, x1, z0, z1, +1, floor);
    planeY(m, h, x0, x1, z0, z1, -1, ceil);
    wallX(m, x0, z0, z1, 0, h, +1, wall);
    wallX(m, x1, z0, z1, 0, h, -1, wall);
    wallZ(m, z0, x0, x1, 0, h, +1, wall);
    wallZ(m, z1, x0, x1, 0, h, -1, wall);
}
void canMesh(Mesh& m, int labelTex) { cylinder(m, Vec3(0, 0.062f, 0), 0.034f, 0.062f, Mat(Vec3(1, 1, 1), labelTex), 8); }

float flicker(float t, float seed) {
    float f = std::sin(t * 13.0f + seed) * std::sin(t * 7.3f + seed * 2.0f);
    return (f > 0.93f) ? 0.35f : 1.0f;
}

}  // namespace

void World::build(Renderer& r) {
    tx_ = generateTextures(r);
    negron_.build(tx_);
    beerCan_.clear();
    canMesh(beerCan_, tx_.beerLabel);
    buildOffice();
    buildLivingRoom();
    buildKitchen();
    buildCorridor();
    buildLogo();
}

// =================================================================== OFFICE

void World::buildOffice() {
    Mesh& m = office_;
    m.clear();
    Mat concrete(rgb(200, 200, 190), tx_.concrete, 1.0f);
    Mat floor(Vec3(1, 1, 1), tx_.linoleum, 1.2f);
    Mat ceil(Vec3(1, 1, 1), tx_.ceiling, 1.0f);
    const float X0 = -1.8f, X1 = 1.8f, Z0 = -2.2f, Z1 = 1.4f, H = 2.6f;

    planeY(m, 0, X0, X1, Z0, Z1, +1, floor, 8);
    planeY(m, H, X0, X1, Z0, Z1, -1, ceil, 6);
    wallZ(m, Z0, X0, X1, 0, H, +1, concrete, 6);
    wallZ(m, Z1, X0, X1, 0, H, -1, concrete, 4);
    // left wall with door opening z in [-1.6,-0.6], y < 2.1
    wallX(m, X0, Z0, -1.6f, 0, H, +1, concrete, 3);
    wallX(m, X0, -0.6f, Z1, 0, H, +1, concrete, 6);
    wallX(m, X0, -1.6f, -0.6f, 2.1f, H, +1, concrete, 2);
    // right wall with window z in [-1.5,-0.3], y in [0.9,1.9]
    wallX(m, X1, Z0, -1.5f, 0, H, -1, concrete, 3);
    wallX(m, X1, -0.3f, Z1, 0, H, -1, concrete, 6);
    wallX(m, X1, -1.5f, -0.3f, 0, 0.9f, -1, concrete, 2);
    wallX(m, X1, -1.5f, -0.3f, 1.9f, H, -1, concrete, 2);
    // the city outside
    wallX(m, 3.4f, -3.5f, 1.6f, -0.6f, 3.4f, -1, Mat(rgb(150, 150, 170), tx_.cityNight, -1.0f, true), 1);
    // window frame + cross
    Mat frame(rgb(210, 205, 190));
    box(m, Vec3(X1, 0.88f, -0.9f), Vec3(0.12f, 0.03f, 0.64f), frame);
    box(m, Vec3(X1, 1.92f, -0.9f), Vec3(0.08f, 0.03f, 0.64f), frame);
    box(m, Vec3(X1, 1.4f, -1.52f), Vec3(0.08f, 0.52f, 0.03f), frame);
    box(m, Vec3(X1, 1.4f, -0.28f), Vec3(0.08f, 0.52f, 0.03f), frame);
    box(m, Vec3(X1, 1.4f, -0.9f), Vec3(0.05f, 0.5f, 0.02f), frame);
    box(m, Vec3(X1, 1.5f, -0.9f), Vec3(0.05f, 0.02f, 0.6f), frame);

    // door frame
    Mat dark(rgb(50, 50, 55));
    box(m, Vec3(X0 + 0.02f, 1.05f, -1.64f), Vec3(0.07f, 1.05f, 0.05f), dark);
    box(m, Vec3(X0 + 0.02f, 1.05f, -0.56f), Vec3(0.07f, 1.05f, 0.05f), dark);
    box(m, Vec3(X0 + 0.02f, 2.13f, -1.1f), Vec3(0.07f, 0.05f, 0.59f), dark);
    // hazard stripes on the door frame floor
    for (int i = 0; i < 5; ++i)
        box(m, Vec3(X0 + 0.08f, 0.005f, -1.5f + i * 0.2f), Vec3(0.06f, 0.005f, 0.05f), Mat(rgb(220, 180, 20)));
    // door control box near door
    box(m, Vec3(X0 + 0.03f, 1.25f, -0.3f), Vec3(0.03f, 0.2f, 0.09f), Mat(rgb(70, 70, 75)));
    box(m, Vec3(X0 + 0.065f, 1.33f, -0.3f), Vec3(0.01f, 0.04f, 0.04f), Mat(rgb(220, 30, 30), -1, 1, true));
    box(m, Vec3(X0 + 0.065f, 1.17f, -0.3f), Vec3(0.01f, 0.04f, 0.04f), Mat(rgb(230, 230, 210), -1, 1, true));

    // desk
    Mat wood(Vec3(1, 1, 1), tx_.wood, 1.5f);
    box(m, Vec3(0, 0.74f, -0.8f), Vec3(1.1f, 0.03f, 0.42f), wood);
    box(m, Vec3(0, 0.38f, -0.4f), Vec3(1.05f, 0.33f, 0.02f), Mat(rgb(150, 150, 150), tx_.wood, 1.5f));
    box(m, Vec3(-1.05f, 0.36f, -0.8f), Vec3(0.03f, 0.36f, 0.4f), wood);
    box(m, Vec3(1.05f, 0.36f, -0.8f), Vec3(0.03f, 0.36f, 0.4f), wood);

    // CRT monitors
    Mat beige(rgb(200, 190, 160));
    for (int s = -1; s <= 1; s += 2) {
        box(m, Vec3(s * 0.45f, 1.0f, -0.92f), Vec3(0.21f, 0.18f, 0.18f), beige);
        box(m, Vec3(s * 0.45f, 0.98f, -1.12f), Vec3(0.15f, 0.13f, 0.08f), beige);
        wallZ(m, -0.735f, s * 0.45f - 0.16f, s * 0.45f + 0.16f, 0.88f, 1.12f, +1,
              Mat(s < 0 ? rgb(40, 90, 60) : rgb(30, 60, 80), -1, 1, true), 1);
        box(m, Vec3(s * 0.45f, 0.79f, -0.95f), Vec3(0.1f, 0.02f, 0.08f), beige);
    }
    // monitor text lines
    for (int i = 0; i < 5; ++i)
        wallZ(m, -0.733f, -0.58f, -0.58f + 0.08f + (i * 37 % 5) * 0.03f, 1.06f - i * 0.04f, 1.075f - i * 0.04f, +1,
              Mat(rgb(120, 255, 160), -1, 1, true), 1);
    // keyboard
    box(m, Vec3(0, 0.78f, -0.55f), Vec3(0.24f, 0.012f, 0.08f), Mat(rgb(180, 175, 150)));
    // red phone
    box(m, Vec3(-0.85f, 0.8f, -0.65f), Vec3(0.1f, 0.04f, 0.08f), Mat(rgb(160, 20, 20)));
    box(m, Vec3(-0.85f, 0.86f, -0.65f), Vec3(0.11f, 0.02f, 0.03f), Mat(rgb(140, 15, 15)));
    // beer cans on the desk
    Mesh can; canMesh(can, tx_.beerLabel);
    m.append(can, Mat4::translate(Vec3(0.2f, 0.77f, -0.62f)));
    m.append(can, Mat4::translate(Vec3(0.31f, 0.77f, -0.68f)));
    m.append(can, Mat4::translate(Vec3(-0.25f, 0.8f, -0.66f)) * Mat4::rotZ(PI / 2) * Mat4::rotY(0.4f));
    // fan base
    cylinder(m, Vec3(0.85f, 0.8f, -0.85f), 0.08f, 0.02f, Mat(rgb(60, 60, 60)), 8);
    cylinder(m, Vec3(0.85f, 0.9f, -0.85f), 0.015f, 0.1f, Mat(rgb(60, 60, 60)), 6);
    box(m, Vec3(0.85f, 1.0f, -0.88f), Vec3(0.04f, 0.04f, 0.05f), Mat(rgb(50, 50, 50)));
    officeFanBlades_.clear();
    for (int i = 0; i < 3; ++i) {
        Mesh blade;
        box(blade, Vec3(0, 0.07f, 0), Vec3(0.03f, 0.07f, 0.004f), Mat(rgb(170, 170, 160)));
        officeFanBlades_.append(blade, Mat4::rotZ(i * 2 * PI / 3));
    }

    // poster on the back wall
    wallZ(m, Z0 + 0.01f, -0.45f, 0.45f, 1.2f, 2.1f, +1, Mat(Vec3(1, 1, 1), tx_.poster, -1.0f), 2);
    // calendar
    wallZ(m, Z0 + 0.01f, 0.9f, 1.3f, 1.3f, 1.8f, +1, Mat(rgb(220, 215, 200)), 1);
    wallZ(m, Z0 + 0.012f, 0.9f, 1.3f, 1.66f, 1.8f, +1, Mat(rgb(180, 30, 30)), 1);
    // ceiling lamp
    box(m, Vec3(0, H - 0.04f, -0.6f), Vec3(0.45f, 0.03f, 0.13f), Mat(rgb(255, 250, 230), -1, 1, true));
    box(m, Vec3(0, H - 0.02f, -0.6f), Vec3(0.48f, 0.02f, 0.16f), Mat(rgb(90, 90, 90)));

    // hallway behind the door
    officeHallway_.clear();
    Mesh& hw = officeHallway_;
    Mat wp(Vec3(0.8f, 0.8f, 0.8f), tx_.wallpaper, 1.3f);
    planeY(hw, 0, -5.2f, X0, -1.6f, -0.6f, +1, Mat(Vec3(1, 1, 1), tx_.linoleum, 1.2f), 4);
    planeY(hw, 2.4f, -5.2f, X0, -1.6f, -0.6f, -1, Mat(Vec3(0.6f, 0.6f, 0.6f), tx_.ceiling), 4);
    wallZ(hw, -1.6f, -5.2f, X0, 0, 2.4f, +1, wp, 5);
    wallZ(hw, -0.6f, -5.2f, X0, 0, 2.4f, -1, wp, 5);
    wallX(hw, -5.2f, -1.6f, -0.6f, 0, 2.4f, +1, wp, 2);

    officeShutter_.clear();
    box(officeShutter_, Vec3(0, 0, 0), Vec3(0.03f, 1.06f, 0.52f), Mat(Vec3(1, 1, 1), tx_.metal, 1.6f), false, 3);
    box(officeShutter_, Vec3(0.035f, -0.9f, 0), Vec3(0.01f, 0.08f, 0.5f), Mat(rgb(200, 160, 20)));
}

void World::renderOffice(Renderer& r, const OfficeView& v) {
    const Vec3 eye(0, 1.25f, 0.7f);
    Vec3 dir(std::sin(v.yaw), -0.07f, -std::cos(v.yaw));
    r.clear(Vec3(0, 0, 0));
    r.setCamera(eye, eye + dir, 60.0f);

    std::vector<Light> lights;
    float amb = 0.07f;
    if (!v.powerOut) {
        lights.push_back({Vec3(0, 2.3f, -0.6f), Vec3(1.0f, 0.88f, 0.68f) * (1.05f * v.lampFlicker), 5.5f});
        lights.push_back({Vec3(-0.45f, 1.0f, -0.5f), Vec3(0.1f, 0.3f, 0.18f), 1.6f});
        lights.push_back({Vec3(0.45f, 1.0f, -0.5f), Vec3(0.08f, 0.2f, 0.3f), 1.6f});
    } else {
        amb = 0.015f;
    }
    lights.push_back({Vec3(2.6f, 1.5f, -0.9f), Vec3(0.12f, 0.15f, 0.32f), 4.0f});  // moonlight from window
    if (v.lightOn && !v.powerOut) lights.push_back({Vec3(-2.4f, 2.1f, -1.1f), Vec3(1.2f, 1.0f, 0.65f), 3.4f});
    r.setEnvironment(Vec3(amb, amb, amb * 1.2f), lights, Vec3(0.0f, 0.0f, 0.01f), 2.5f, 9.0f);

    r.drawMesh(office_);
    // the hallway is pitch dark unless the door light is on
    if (!(v.lightOn && !v.powerOut)) {
        r.setEnvironment(Vec3(0.01f, 0.01f, 0.012f), {}, Vec3(0, 0, 0), 0.5f, 3.0f);
    }
    r.drawMesh(officeHallway_);

    if (v.negronAtDoor && v.doorClosed < 0.95f) {
        bool visible = v.lightOn && !v.powerOut;
        NegronPose p = NegronModel::atDoor(v.t, v.negronRampage);
        if (!visible) {
            // only the glowing eyes in the dark
            r.setEnvironment(Vec3(0, 0, 0), {}, Vec3(0, 0, 0), 0.5f, 3.0f);
            p.glowEyes = v.eyesInDark || v.negronRampage;
        }
        if (visible || p.glowEyes)
            negron_.draw(r, Mat4::translate(Vec3(-2.3f, 0.95f, -1.1f)) * Mat4::rotY(PI / 2), p);
    }
    // restore office lighting for the shutter + fan
    r.setEnvironment(Vec3(amb, amb, amb * 1.2f), lights, Vec3(0.0f, 0.0f, 0.01f), 2.5f, 9.0f);
    float y = lerpf(3.75f, 1.06f, smooth01(v.doorClosed));
    r.drawMesh(officeShutter_, Mat4::translate(Vec3(-1.73f, y, -1.1f)));
    float fanSpeed = v.powerOut ? 0.0f : 18.0f;
    r.drawMesh(officeFanBlades_, Mat4::translate(Vec3(0.85f, 1.0f, -0.82f)) * Mat4::rotZ(v.t * fanSpeed));
}

// =================================================================== LIVING ROOM (CAM 1)

void World::buildLivingRoom() {
    Mesh& m = living_;
    m.clear();
    Mat wp(Vec3(1, 1, 1), tx_.wallpaper, 1.2f);
    room(m, -2.6f, 2.6f, -2.0f, 2.0f, 2.6f, wp, Mat(Vec3(1, 1, 1), tx_.wood, 1.0f), Mat(rgb(170, 165, 150), tx_.ceiling));

    // THE wall carpet
    wallZ(m, -1.985f, -1.55f, 0.95f, 0.95f, 2.35f, +1, Mat(Vec3(1, 1, 1), tx_.carpet, -1.0f), 3);
    // couch
    Mat fab(Vec3(1, 1, 1), tx_.fabric, 2.0f);
    box(m, Vec3(-0.3f, 0.24f, -1.5f), Vec3(1.0f, 0.22f, 0.42f), fab, false, 2);
    box(m, Vec3(-0.3f, 0.7f, -1.84f), Vec3(1.0f, 0.36f, 0.12f), fab, false, 2);
    box(m, Vec3(-1.38f, 0.4f, -1.5f), Vec3(0.1f, 0.38f, 0.42f), fab);
    box(m, Vec3(0.78f, 0.4f, -1.5f), Vec3(0.1f, 0.38f, 0.42f), fab);
    box(m, Vec3(-0.8f, 0.5f, -1.45f), Vec3(0.46f, 0.05f, 0.34f), Mat(rgb(150, 100, 70), tx_.fabric, 2.0f));
    box(m, Vec3(0.2f, 0.5f, -1.45f), Vec3(0.46f, 0.05f, 0.34f), Mat(rgb(150, 100, 70), tx_.fabric, 2.0f));
    // coffee table + cans
    Mat wood(Vec3(1, 1, 1), tx_.wood, 1.5f);
    box(m, Vec3(-0.35f, 0.42f, -0.5f), Vec3(0.6f, 0.025f, 0.3f), wood);
    for (int sx = -1; sx <= 1; sx += 2)
        for (int sz = -1; sz <= 1; sz += 2)
            box(m, Vec3(-0.35f + sx * 0.55f, 0.2f, -0.5f + sz * 0.25f), Vec3(0.025f, 0.2f, 0.025f), wood);
    Mesh can; canMesh(can, tx_.beerLabel);
    const float cans[][3] = {{-0.6f, -0.45f, 0}, {-0.45f, -0.6f, 0}, {-0.1f, -0.42f, 1}, {0.05f, -0.6f, 0}, {-0.3f, -0.5f, 1}};
    for (auto& c : cans) {
        if (c[2] > 0) m.append(can, Mat4::translate(Vec3(c[0], 0.48f, c[1])) * Mat4::rotZ(PI / 2) * Mat4::rotY(c[0] * 5));
        else m.append(can, Mat4::translate(Vec3(c[0], 0.445f, c[1])));
    }
    // cans on the floor around the couch
    for (int i = 0; i < 7; ++i) {
        float x = -1.2f + i * 0.33f + std::sin(i * 3.1f) * 0.1f;
        float z = -0.95f + std::cos(i * 2.3f) * 0.12f;
        m.append(can, Mat4::translate(Vec3(x, 0.035f, z)) * Mat4::rotY(i * 1.3f) * Mat4::rotZ(PI / 2) * Mat4::translate(Vec3(0, -0.062f, 0)));
    }
    // floor lamp (torsher)
    cylinder(m, Vec3(1.15f, 0.02f, -1.6f), 0.15f, 0.02f, Mat(rgb(40, 40, 40)), 8);
    cylinder(m, Vec3(1.15f, 0.8f, -1.6f), 0.015f, 0.8f, Mat(rgb(40, 40, 40)), 6);
    cylinder(m, Vec3(1.15f, 1.65f, -1.6f), 0.2f, 0.14f, Mat(rgb(255, 190, 120), -1, 1, true), 8, false);
    // TV on a stand, angled toward the couch
    Mesh tv;
    box(tv, Vec3(0, -0.5f, 0), Vec3(0.42f, 0.3f, 0.3f), wood);
    box(tv, Vec3(0, 0.05f, -0.05f), Vec3(0.34f, 0.25f, 0.27f), Mat(rgb(45, 42, 40)));
    box(tv, Vec3(0.25f, -0.1f, 0.225f), Vec3(0.03f, 0.03f, 0.005f), Mat(rgb(255, 30, 30), -1, 1, true));
    m.append(tv, Mat4::translate(Vec3(-1.95f, 0.8f, 0.7f)) * Mat4::rotY(2.5f));
    tvScreenOn_.clear();
    tvScreenOff_.clear();
    wallZ(tvScreenOn_, 0.222f, -0.27f, 0.27f, -0.14f, 0.24f, +1, Mat(Vec3(1, 1, 1), tx_.tvFootball, -1.0f, true), 1);
    wallZ(tvScreenOff_, 0.222f, -0.27f, 0.27f, -0.14f, 0.24f, +1, Mat(rgb(20, 25, 25)), 1);
    // window on the right wall with curtains
    wallX(m, 2.59f, -1.2f, 0.2f, 1.0f, 2.1f, -1, Mat(rgb(120, 120, 140), tx_.cityNight, -1.0f, true), 1);
    box(m, Vec3(2.55f, 1.6f, -1.35f), Vec3(0.04f, 0.75f, 0.2f), Mat(rgb(120, 40, 40), tx_.fabric, 3));
    box(m, Vec3(2.55f, 1.6f, 0.35f), Vec3(0.04f, 0.75f, 0.2f), Mat(rgb(120, 40, 40), tx_.fabric, 3));
    // the BEER PIPE ("pivoprovod"): from the ceiling down to the couch armrest
    Mat pipe(rgb(150, 150, 140));
    cylinder(m, Vec3(0.95f, 1.85f, -1.82f), 0.06f, 0.75f, pipe, 8);
    box(m, Vec3(0.95f, 1.08f, -1.75f), Vec3(0.09f, 0.04f, 0.12f), pipe);
    box(m, Vec3(0.95f, 1.06f, -1.66f), Vec3(0.07f, 0.02f, 0.06f), Mat(rgb(40, 40, 40)));
    box(m, Vec3(0.95f, 1.45f, -1.76f), Vec3(0.1f, 0.05f, 0.005f), Mat(rgb(230, 190, 40), -1, 1, true));  // yellow warning tag
    beerCan_.clear();
    canMesh(beerCan_, tx_.beerLabel);
}

static NegronPose sofaPose(const RoomView& v) {
    return NegronModel::sitting(v.t, v.drinkAnim, v.asleep);
}

void World::renderCamera(Renderer& r, CamId cam, const RoomView& v) {
    r.clear(Vec3(0, 0, 0));
    std::vector<Light> L;
    Vec3 fog(0.0f, 0.0f, 0.0f);

    if (cam == CamId::LivingRoom) {
        r.setCamera(Vec3(1.45f, 2.05f, 0.75f), Vec3(-0.5f, 0.72f, -1.45f), 56.0f);
        L.push_back({Vec3(1.8f, 2.2f, 1.6f), Vec3(0.35f, 0.4f, 0.35f), 6.5f});  // camera IR illuminator
        L.push_back({Vec3(1.15f, 1.5f, -1.5f), Vec3(1.2f, 0.8f, 0.45f) * flicker(v.t, 1.0f), 4.5f});
        L.push_back({Vec3(2.4f, 1.6f, -0.5f), Vec3(0.1f, 0.12f, 0.3f), 4.0f});
        if (v.tvOn) L.push_back({Vec3(-1.6f, 1.0f, 0.3f), Vec3(0.25f, 0.6f, 0.35f) * (0.8f + 0.2f * std::sin(v.t * 9)), 3.8f});
        r.setEnvironment(Vec3(0.1f, 0.1f, 0.11f), L, fog, 3.5f, 10.0f);
        r.drawMesh(living_);
        Mat4 tvXf = Mat4::translate(Vec3(-1.95f, 0.8f, 0.7f)) * Mat4::rotY(2.5f);
        r.drawMesh(v.tvOn ? tvScreenOn_ : tvScreenOff_, tvXf);
        if (v.loc == NegronLoc::Sofa)
            negron_.draw(r, Mat4::translate(Vec3(-0.45f, 0.56f, -1.52f)), sofaPose(v));
        if (v.beerDrop >= 0 && v.beerDrop < 1.2f) {
            float k = clampf(v.beerDrop / 0.35f, 0, 1);
            Vec3 p = lerp(Vec3(0.95f, 1.0f, -1.66f), Vec3(0.83f, 0.78f, -1.45f), k * k);
            r.drawMesh(beerCan_, Mat4::translate(p) * Mat4::rotX(v.beerDrop * 9.0f));
        }
    } else if (cam == CamId::Kitchen) {
        r.setCamera(Vec3(1.75f, 2.3f, 1.55f), Vec3(-0.75f, 0.85f, -1.0f), 64.0f);
        bool here = v.loc == NegronLoc::Kitchen;
        L.push_back({Vec3(1.6f, 2.2f, 1.4f), Vec3(0.3f, 0.35f, 0.3f), 6.0f});  // camera IR illuminator
        L.push_back({Vec3(0.0f, 2.1f, -0.2f), Vec3(0.95f, 0.8f, 0.5f) * flicker(v.t, 4.0f), 4.5f});
        L.push_back({Vec3(-2.0f, 1.5f, 0.5f), Vec3(0.08f, 0.1f, 0.25f), 3.5f});
        if (here) L.push_back({Vec3(-1.3f, 1.0f, -0.75f), Vec3(0.55f, 0.65f, 0.75f), 3.0f});
        r.setEnvironment(Vec3(0.09f, 0.09f, 0.1f), L, fog, 3.5f, 10.0f);
        r.drawMesh(kitchen_);
        float open = here ? smooth01(v.stateTime / 1.2f) * 1.9f : 0.0f;
        if (here) r.drawMesh(fridgeInside_);
        r.drawMesh(fridgeDoor_, Mat4::translate(Vec3(-0.96f, 0.9f, -1.12f)) * Mat4::rotY(open));
        if (here) {
            // looks over his shoulder at the camera now and then
            float look = smooth01((std::sin(v.stateTime * 0.9f) - 0.3f) * 2.0f);
            NegronPose p = NegronModel::standing(v.t, look);
            p.glowEyes = look > 0.6f;
            negron_.draw(r, Mat4::translate(Vec3(-1.2f, 0.95f, -0.5f)) * Mat4::rotY(PI), p);
        }
    } else {
        r.setCamera(Vec3(0.55f, 2.2f, 0.8f), Vec3(-0.1f, 1.0f, -5.0f), 58.0f);
        L.push_back({Vec3(0, 2.2f, -3.2f), Vec3(1.1f, 0.9f, 0.55f) * flicker(v.t, 7.0f), 5.5f});
        L.push_back({Vec3(0, 2.1f, -5.8f), Vec3(0.3f, 0.25f, 0.2f), 3.0f});
        L.push_back({Vec3(0.4f, 2.1f, 0.5f), Vec3(0.35f, 0.4f, 0.35f), 6.5f});  // camera IR illuminator
        r.setEnvironment(Vec3(0.07f, 0.07f, 0.08f), L, fog, 4.0f, 11.0f);
        r.drawMesh(corridor_);
        if (v.loc == NegronLoc::Corridor) {
            float z = lerpf(-6.2f, -1.4f, v.progress);
            negron_.draw(r, Mat4::translate(Vec3(-0.1f, 0.95f + std::fabs(std::sin(v.t * (v.rampage ? 9 : 5))) * 0.03f, z)),
                         NegronModel::walking(v.t, v.rampage));
        }
    }
}

// =================================================================== KITCHEN (CAM 2)

void World::buildKitchen() {
    Mesh& m = kitchen_;
    m.clear();
    Mat wp(Vec3(0.9f, 0.95f, 0.85f), tx_.wallpaper, 1.2f);
    room(m, -2.0f, 2.0f, -1.8f, 1.8f, 2.5f, wp, Mat(Vec3(1, 1, 1), tx_.linoleum, 1.5f), Mat(rgb(160, 160, 150), tx_.ceiling));
    Mat tiles(Vec3(1, 1, 1), tx_.tiles, 2.0f);
    wallZ(m, -1.79f, -2.0f, 2.0f, 0, 1.4f, +1, tiles, 4);
    wallX(m, -1.99f, -1.8f, 1.8f, 0, 1.4f, +1, tiles, 4);
    // ZIL fridge body
    Mat white(rgb(225, 225, 212));
    box(m, Vec3(-1.3f, 0.9f, -1.47f), Vec3(0.34f, 0.9f, 0.32f), white, false, 2);
    box(m, Vec3(-1.3f, 1.81f, -1.47f), Vec3(0.36f, 0.02f, 0.34f), Mat(rgb(200, 200, 190)));
    fridgeInside_.clear();
    wallZ(fridgeInside_, -1.145f, -1.6f, -1.0f, 0.1f, 1.7f, +1, Mat(rgb(200, 220, 235), -1, 1, true), 1);
    for (int i = 0; i < 4; ++i)
        box(fridgeInside_, Vec3(-1.3f, 0.45f + i * 0.35f, -1.14f), Vec3(0.3f, 0.008f, 0.01f), Mat(rgb(120, 130, 140), -1, 1, true));
    box(fridgeInside_, Vec3(-1.15f, 0.83f, -1.15f), Vec3(0.04f, 0.06f, 0.012f), Mat(rgb(150, 160, 120), -1, 1, true));  // a lonely jar
    fridgeDoor_.clear();
    box(fridgeDoor_, Vec3(-0.34f, 0, 0.03f), Vec3(0.34f, 0.88f, 0.03f), white);
    box(fridgeDoor_, Vec3(-0.62f, 0.25f, 0.075f), Vec3(0.015f, 0.12f, 0.015f), Mat(rgb(170, 170, 170)));
    box(fridgeDoor_, Vec3(-0.34f, 0.55f, 0.062f), Vec3(0.08f, 0.02f, 0.002f), Mat(rgb(180, 30, 30)));  // "ZIL" badge
    // stove
    box(m, Vec3(0.0f, 0.45f, -1.48f), Vec3(0.3f, 0.45f, 0.3f), white);
    for (int i = 0; i < 4; ++i)
        cylinder(m, Vec3(-0.12f + (i % 2) * 0.24f, 0.905f, -1.58f + (i / 2) * 0.22f), 0.07f, 0.008f, Mat(rgb(25, 25, 25)), 8);
    // cupboard + sink
    Mat wood(Vec3(0.9f, 0.9f, 0.9f), tx_.wood, 1.5f);
    box(m, Vec3(0.85f, 0.43f, -1.48f), Vec3(0.5f, 0.43f, 0.3f), wood);
    box(m, Vec3(0.85f, 0.87f, -1.48f), Vec3(0.52f, 0.02f, 0.32f), Mat(rgb(150, 150, 150)));
    box(m, Vec3(0.85f, 1.9f, -1.6f), Vec3(0.6f, 0.3f, 0.18f), wood);
    // kitchen table with oilcloth + stools
    box(m, Vec3(0.4f, 0.74f, 0.4f), Vec3(0.6f, 0.02f, 0.4f), Mat(rgb(220, 90, 80), tx_.linoleum, 3.0f));
    for (int sx = -1; sx <= 1; sx += 2)
        for (int sz = -1; sz <= 1; sz += 2)
            box(m, Vec3(0.4f + sx * 0.55f, 0.37f, 0.4f + sz * 0.35f), Vec3(0.025f, 0.37f, 0.025f), wood);
    for (int i = 0; i < 2; ++i) {
        box(m, Vec3(-0.45f + i * 1.7f, 0.45f, 0.4f), Vec3(0.17f, 0.02f, 0.17f), wood);
        cylinder(m, Vec3(-0.45f + i * 1.7f, 0.22f, 0.4f), 0.03f, 0.22f, wood, 6);
    }
    Mesh can; canMesh(can, tx_.beerLabel);
    m.append(can, Mat4::translate(Vec3(0.2f, 0.76f, 0.3f)));
    m.append(can, Mat4::translate(Vec3(0.6f, 0.8f, 0.5f)) * Mat4::rotZ(PI / 2));
    // window
    wallX(m, -1.985f, -0.3f, 0.9f, 1.0f, 2.0f, +1, Mat(rgb(120, 120, 140), tx_.cityNight, -1.0f, true), 1);
    box(m, Vec3(-1.97f, 1.5f, 0.3f), Vec3(0.03f, 0.5f, 0.02f), Mat(rgb(210, 205, 190)));
    // hanging bulb
    cylinder(m, Vec3(0, 2.35f, -0.2f), 0.005f, 0.15f, Mat(rgb(20, 20, 20)), 4, false);
    ellipsoid(m, Vec3(0, 2.15f, -0.2f), Vec3(0.04f, 0.05f, 0.04f), Mat(rgb(255, 220, 150), -1, 1, true), 6, 4);
}

// =================================================================== CORRIDOR (CAM 3)

void World::buildCorridor() {
    Mesh& m = corridor_;
    m.clear();
    Mat wp(Vec3(0.9f, 0.85f, 0.8f), tx_.wallpaper, 1.3f);
    room(m, -0.85f, 0.85f, -7.0f, 1.0f, 2.5f, wp, Mat(Vec3(1, 1, 1), tx_.wood, 1.5f), Mat(rgb(150, 145, 135), tx_.ceiling));
    // runner rug
    planeY(m, 0.005f, -0.4f, 0.4f, -6.8f, 0.8f, +1, Mat(rgb(150, 40, 40), tx_.carpet, 1.0f), 6);
    // doors along the walls
    Mat door(Vec3(0.8f, 0.8f, 0.8f), tx_.wood, 2.0f);
    const float doors[][2] = {{-1, -2.0f}, {1, -3.6f}, {-1, -5.0f}};
    for (auto& d : doors) {
        float x = d[0] * 0.84f;
        box(m, Vec3(x, 1.0f, d[1]), Vec3(0.03f, 1.0f, 0.4f), door);
        box(m, Vec3(x - d[0] * 0.04f, 1.0f, d[1] + 0.3f), Vec3(0.02f, 0.03f, 0.03f), Mat(rgb(200, 180, 80)));
    }
    // end wall door (the bathroom) - slightly open, dark gap
    wallZ(m, -6.99f, -0.45f, 0.45f, 0, 2.0f, +1, door, 2);
    wallZ(m, -6.985f, 0.3f, 0.45f, 0, 2.0f, +1, Mat(rgb(5, 5, 5)), 1);
    // coat rack with a hat, shoes
    box(m, Vec3(0.8f, 1.7f, -1.2f), Vec3(0.04f, 0.03f, 0.5f), door);
    ellipsoid(m, Vec3(0.72f, 1.62f, -1.0f), Vec3(0.12f, 0.1f, 0.12f), Mat(rgb(90, 60, 35)), 6, 4);  // dedushka's ushanka
    box(m, Vec3(0.74f, 1.3f, -1.4f), Vec3(0.06f, 0.35f, 0.2f), Mat(rgb(50, 55, 45)));                // coat
    for (int i = 0; i < 3; ++i)
        box(m, Vec3(0.6f, 0.05f, -0.6f - i * 0.3f), Vec3(0.06f, 0.05f, 0.13f), Mat(rgb(30, 25, 20)));
    // light bulb
    ellipsoid(m, Vec3(0, 2.3f, -3.2f), Vec3(0.04f, 0.05f, 0.04f), Mat(rgb(255, 220, 150), -1, 1, true), 6, 4);
    // a framed photo of Ded
    wallX(m, -0.84f, -3.6f, -3.0f, 1.3f, 1.9f, +1, Mat(Vec3(1, 1, 1), tx_.poster, -1.0f), 1);
}

// =================================================================== JUMPSCARE

void World::renderJumpscare(Renderer& r, float t, bool dark) {
    OfficeView ov;
    ov.t = t;
    ov.yaw = 0;
    ov.powerOut = dark;
    ov.lampFlicker = (int(t * 30) % 2) ? 1.0f : 0.3f;
    renderOffice(r, ov);
    const Vec3 eye(0, 1.25f, 0.7f);
    std::vector<Light> L = {{eye + Vec3(0, 0.4f, 0.1f), Vec3(1.0f, 0.9f, 0.8f), 2.5f}};
    r.setEnvironment(Vec3(0.12f, 0.08f, 0.08f), L, Vec3(0, 0, 0), 4, 10);
    float k = smooth01(t / 0.22f);
    float d = lerpf(1.6f, 0.62f, k);
    float jitterX = std::sin(t * 61) * 0.02f, jitterY = std::cos(t * 47) * 0.015f;
    NegronPose p = NegronModel::lunge(t);
    negron_.draw(r, Mat4::translate(Vec3(jitterX, 0.47f + jitterY, 0.7f - d)), p);
}

// =================================================================== LOGO

void World::buildLogo() {
    Mesh& m = skull_;
    m.clear();
    Mat bone(rgb(230, 222, 200));
    ellipsoid(m, Vec3(0, 0.1f, 0), Vec3(0.5f, 0.48f, 0.52f), bone, 12, 9);
    box(m, Vec3(0, -0.34f, 0.12f), Vec3(0.3f, 0.12f, 0.3f), bone);
    ellipsoid(m, Vec3(-0.3f, -0.12f, 0.3f), Vec3(0.12f, 0.1f, 0.12f), bone, 6, 4);
    ellipsoid(m, Vec3(0.3f, -0.12f, 0.3f), Vec3(0.12f, 0.1f, 0.12f), bone, 6, 4);
    for (int s = -1; s <= 1; s += 2) {
        ellipsoid(m, Vec3(s * 0.19f, 0.04f, 0.4f), Vec3(0.13f, 0.12f, 0.12f), Mat(rgb(10, 0, 0)), 8, 6);
        ellipsoid(m, Vec3(s * 0.19f, 0.04f, 0.5f), Vec3(0.03f, 0.03f, 0.03f), Mat(rgb(255, 30, 20), -1, 1, true), 6, 4);
        // round-ish glasses: square frames
        Mat fr(rgb(20, 20, 20));
        float cx = s * 0.19f, cy = 0.04f, z = 0.6f;
        box(m, Vec3(cx, cy + 0.15f, z), Vec3(0.16f, 0.015f, 0.015f), fr);
        box(m, Vec3(cx, cy - 0.15f, z), Vec3(0.16f, 0.015f, 0.015f), fr);
        box(m, Vec3(cx - 0.15f, cy, z), Vec3(0.015f, 0.15f, 0.015f), fr);
        box(m, Vec3(cx + 0.15f, cy, z), Vec3(0.015f, 0.15f, 0.015f), fr);
        box(m, Vec3(s * 0.43f, cy + 0.1f, 0.32f), Vec3(0.012f, 0.012f, 0.28f), fr);  // temples
    }
    box(m, Vec3(0, 0.04f + 0.14f, 0.6f), Vec3(0.04f, 0.012f, 0.012f), Mat(rgb(20, 20, 20)));  // bridge
    box(m, Vec3(0, -0.12f, 0.49f), Vec3(0.05f, 0.07f, 0.04f), Mat(rgb(15, 0, 0)));             // nose hole
    for (int i = -4; i <= 4; ++i)
        box(m, Vec3(i * 0.05f, -0.27f, 0.42f), Vec3(0.02f, 0.035f, 0.01f), Mat(rgb(245, 240, 225)));
    // grandpa beard + moustache
    Mat beard(rgb(200, 200, 205));
    ellipsoid(m, Vec3(0, -0.55f, 0.25f), Vec3(0.34f, 0.32f, 0.22f), beard, 10, 6);
    ellipsoid(m, Vec3(-0.12f, -0.2f, 0.44f), Vec3(0.14f, 0.05f, 0.06f), beard, 8, 4);
    ellipsoid(m, Vec3(0.12f, -0.2f, 0.44f), Vec3(0.14f, 0.05f, 0.06f), beard, 8, 4);
    // ushanka
    Mat fur(rgb(95, 62, 36));
    ellipsoid(m, Vec3(0, 0.38f, -0.02f), Vec3(0.57f, 0.34f, 0.57f), fur, 12, 8);
    box(m, Vec3(0, 0.6f, 0.46f), Vec3(0.42f, 0.13f, 0.08f), fur);
    box(m, Vec3(0, 0.6f, 0.545f), Vec3(0.06f, 0.06f, 0.006f), Mat(rgb(220, 20, 20), -1, 1, true));  // red badge
    box(m, Vec3(-0.56f, 0.05f, 0), Vec3(0.08f, 0.32f, 0.26f), fur);
    box(m, Vec3(0.56f, 0.05f, 0), Vec3(0.08f, 0.32f, 0.26f), fur);
}

void World::renderLogo(Renderer& r, float t) {
    r.clear(Vec3(0, 0, 0));
    // dark red radial backdrop
    Vec3* px = r.pixels();
    for (int y = 0; y < Renderer::H; ++y)
        for (int x = 0; x < Renderer::W; ++x) {
            float dx = (x - Renderer::W * 0.5f) / Renderer::W, dy = (y - Renderer::H * 0.4f) / Renderer::H;
            float d = clampf(1.0f - std::sqrt(dx * dx + dy * dy) * 2.2f, 0, 1);
            px[y * Renderer::W + x] = Vec3(0.28f, 0.02f, 0.02f) * d;
        }
    r.setCamera(Vec3(0, 0.05f, 2.9f), Vec3(0, 0.0f, 0), 40.0f);
    std::vector<Light> L = {
        {Vec3(-1.0f, 1.4f, 2.6f), Vec3(1.7f, 1.55f, 1.4f), 7.0f},
        {Vec3(1.2f, -1.2f, 1.6f), Vec3(1.3f, 0.15f, 0.08f), 5.0f},
        {Vec3(0.0f, 2.0f, -1.5f), Vec3(0.6f, 0.2f, 0.15f), 4.0f},
    };
    r.setEnvironment(Vec3(0.2f, 0.14f, 0.14f), L, Vec3(0, 0, 0), 10, 20);
    float yaw = std::sin(t * 0.9f) * 0.5f;
    float bob = std::sin(t * 2.0f) * 0.03f;
    float jaw = std::max(0.0f, std::sin(t * 6.0f)) * 0.0f;
    (void)jaw;
    r.drawMesh(skull_, Mat4::translate(Vec3(0, 0.38f + bob, 0)) * Mat4::rotY(yaw) * Mat4::rotX(0.08f) * Mat4::scale(Vec3(0.62f, 0.62f, 0.62f)));
}

void World::renderMenuBackground(Renderer& r, float t) {
    RoomView v;
    v.t = t;
    v.loc = NegronLoc::Sofa;
    v.tvOn = true;
    v.drinkAnim = std::fmod(t, 14.0f) > 11.6f ? (std::fmod(t, 14.0f) - 11.6f) : 0.0f;
    r.clear(Vec3(0, 0, 0));
    float drift = std::sin(t * 0.15f) * 0.4f;
    r.setCamera(Vec3(0.9f + drift, 1.35f, 0.9f), Vec3(-0.45f + drift * 0.3f, 0.95f, -1.5f), 50.0f);
    std::vector<Light> L;
    L.push_back({Vec3(1.15f, 1.5f, -1.5f), Vec3(1.1f, 0.7f, 0.4f) * flicker(t, 2.0f), 4.0f});
    L.push_back({Vec3(-1.4f, 1.0f, 0.2f), Vec3(0.35f, 0.75f, 0.45f) * (0.75f + 0.25f * std::sin(t * 7)), 4.0f});
    r.setEnvironment(Vec3(0.07f, 0.07f, 0.08f), L, Vec3(0, 0, 0), 3.0f, 8.0f);
    r.drawMesh(living_);
    r.drawMesh(tvScreenOn_, Mat4::translate(Vec3(-1.95f, 0.8f, 0.7f)) * Mat4::rotY(2.5f));
    NegronPose p = NegronModel::sitting(t, v.drinkAnim, false);
    // every few seconds he stares straight at you
    float stare = smooth01((std::sin(t * 0.5f) - 0.6f) * 3.0f);
    p.headYaw = lerpf(p.headYaw, 0.55f, stare);
    p.glowEyes = stare > 0.8f;
    negron_.draw(r, Mat4::translate(Vec3(-0.45f, 0.56f, -1.52f)), p);
}
