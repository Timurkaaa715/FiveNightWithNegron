// Headless test runner (desktop/CI only — not shipped on phones).
//   fnad_headless screens <dir>   -> PPM screenshots of every screen
//   fnad_headless video <dir>     -> raw RGBA frames + WAV of a scripted demo (pipe to ffmpeg)
//   fnad_headless sim             -> balance simulation with a simple bot
#include <cstdio>
#include <cstring>
#include <fstream>
#include <functional>
#include <string>
#include <vector>
#include "../game/Game.h"
#include "../game/World.h"

static void savePPM(Game& g, const std::string& path) {
    std::vector<uint32_t> px(Renderer::W * Renderer::H);
    g.renderer().resolve(px.data());
    FILE* f = std::fopen(path.c_str(), "wb");
    std::fprintf(f, "P6\n%d %d\n255\n", Renderer::W, Renderer::H);
    for (uint32_t p : px) {
        unsigned char c[3] = {uint8_t(p & 0xFF), uint8_t((p >> 8) & 0xFF), uint8_t((p >> 16) & 0xFF)};
        std::fwrite(c, 1, 3, f);
    }
    std::fclose(f);
}

static void step(Game& g, float sec, float dt = 1.0f / 30) {
    for (float t = 0; t < sec; t += dt) g.update(dt);
}

static void tapAt(Game& g, float x, float y) {
    g.pointerDown(x, y, 1);
    g.pointerUp(x, y, 1);
}

static int screens(const std::string& dir) {
    Game g;
    g.init("");
    auto shot = [&](const char* name) { g.render(); savePPM(g, dir + "/" + name + ".ppm"); std::printf("shot %s\n", name); };
    step(g, 2.6f); shot("01_logo");
    step(g, 3.0f); shot("02_warning");
    step(g, 4.0f); shot("03_menu");
    tapAt(g, 100, 160);  // new game
    step(g, 1.5f); shot("04_night_intro");
    g.debugStartNight(1);
    step(g, 9.0f); shot("05_office_sms");
    // look left at the door
    g.key(Key::Left, true); step(g, 1.0f); g.key(Key::Left, false);
    shot("06_office_door");
    g.key(Key::Light, true); step(g, 0.2f); shot("07_door_light_empty"); g.key(Key::Light, false);
    // cameras
    g.key(Key::Camera, true); g.key(Key::Camera, false); step(g, 1.0f);
    shot("08_cam1_sofa");
    g.key(Key::Tv, true); g.key(Key::Beer, true); step(g, 1.1f); shot("09_cam1_drinking_tv");
    g.debugNegron().debugForce(NegronLoc::Kitchen, 30, false, 2.0f);
    g.key(Key::Cam2, true); step(g, 0.8f); shot("10_cam2_kitchen");
    g.debugNegron().debugForce(NegronLoc::Corridor, 10, false, 6.0f);
    g.key(Key::Cam3, true); step(g, 0.8f); shot("11_cam3_corridor");
    g.debugNegron().debugForce(NegronLoc::Corridor, 10, true, 5.0f);
    step(g, 0.5f); shot("12_cam3_rampage");
    g.key(Key::Cam1, true); step(g, 0.8f); shot("13_cam1_empty");
    g.key(Key::Camera, true); step(g, 0.5f);
    g.debugNegron().debugForce(NegronLoc::Door, 0, false);
    g.key(Key::Light, true); step(g, 0.3f); shot("14_door_negron_lit"); g.key(Key::Light, false);
    step(g, 0.1f); shot("15_door_negron_dark");
    g.key(Key::Door, true); step(g, 0.6f); shot("16_door_closed");
    // jumpscare
    g.key(Key::Door, true); step(g, 0.5f);
    g.debugNegron().debugForce(NegronLoc::Corridor, 0.1f, false);
    for (int i = 0; i < 200 && g.state() == Game::State::Playing; ++i) g.update(1.0f / 30);
    step(g, 0.12f); shot("17_jumpscare");
    step(g, 0.35f); shot("18_jumpscare_b");
    step(g, 3.5f); shot("19_game_over");
    // win screen
    g.debugStartNight(1);
    g.debugNegron().debugForce(NegronLoc::Sofa, 0);
    for (int i = 0; i < 30 * 280 && g.state() == Game::State::Playing; ++i) {
        if (g.debugNegron().loc() != NegronLoc::Sofa) g.debugNegron().debugForce(NegronLoc::Sofa, 0);
        g.update(1.0f / 30);
    }
    step(g, 3.5f); shot("20_six_am");
    g.debugStartNight(5);
    for (int i = 0; i < 30 * 280 && g.state() == Game::State::Playing; ++i) {
        g.debugNegron().debugForce(NegronLoc::Sofa, 0);
        g.update(1.0f / 30);
    }
    step(g, 8.0f); shot("21_alpha_end");
    return 0;
}

// --- balance simulation: a bot that plays like an average human ---
static int sim() {
    for (int night = 1; night <= 5; ++night) {
        int wins = 0, powerDeaths = 0, rampages = 0;
        float powerLeft = 0;
        const int RUNS = 60;
        for (int run = 0; run < RUNS; ++run) {
            Game g;
            g.init("");
            g.update(float(run) * 0.013f);
            g.debugStartNight(night);
            Rng rng(run * 31 + night);
            float checkTimer = 0, reaction = -1;
            bool wantDoor = false, seenInCorridor = false;
            while (g.state() == Game::State::Playing) {
                float dt = 1.0f / 20;
                g.update(dt);
                checkTimer -= dt;
                NegronAI& n = g.debugNegron();
                if (n.events().rampageStart) rampages++;
                // checks cameras every 7-11 s
                if (checkTimer <= 0) {
                    checkTimer = rng.range(7, 11);
                    if (!g.cameraUp()) g.key(Key::Camera, true);
                    g.key(Key::Cam1, true);
                    if (n.loc() == NegronLoc::Corridor) seenInCorridor = true;  // he isn't on the couch -> look around
                    if (n.loc() == NegronLoc::Sofa && n.thirst() > 55 && n.drunk() < 70 && g.beerLeft() > 0) g.key(Key::Beer, true);
                    if (n.loc() == NegronLoc::Kitchen && g.beerLeft() > 2 && n.drunk() < 65) g.key(Key::Beer, true);
                    if (night >= 3 && !g.tvOn() && g.power() > 35) g.key(Key::Tv, true);
                    if (g.tvOn() && g.power() < 25) g.key(Key::Tv, true);
                    g.key(Key::Camera, true);
                }
                // hears loud footsteps (late corridor) or the burp at the door -> closes after a human delay
                if (n.loc() != NegronLoc::Corridor && n.loc() != NegronLoc::Door) seenInCorridor = false;
                bool hearsSteps = n.loc() == NegronLoc::Corridor && n.progress() > 0.75f && !n.sneaking();
                bool threat = n.loc() == NegronLoc::Door || hearsSteps || seenInCorridor;
                if (threat != wantDoor) { wantDoor = threat; reaction = rng.range(0.5f, 1.6f); }
                if (reaction >= 0) {
                    reaction -= dt;
                    if (reaction < 0 && g.doorClosed() != wantDoor) {
                        if (g.cameraUp()) g.key(Key::Camera, true);
                        g.key(Key::Door, true);
                    }
                }
            }
            if (g.state() == Game::State::SixAM) { wins++; powerLeft += g.power(); }
            else if (g.power() <= 0) powerDeaths++;
        }
        std::printf("night %d: wins %2d/%d  power-out deaths %2d  rampages %3d  avg power at 6AM %.0f%%\n", night, wins, RUNS,
                    powerDeaths, rampages, wins ? powerLeft / wins : 0.0f);
    }
    return 0;
}

// --- scripted demo for a trailer video: writes frames.rgba and audio.wav ---
static int video(const std::string& dir) {
    Game g;
    g.init("");
    const int FPS = 30;
    const float dt = 1.0f / FPS;
    FILE* frames = std::fopen((dir + "/frames.rgba").c_str(), "wb");
    std::vector<float> audioBuf;
    std::vector<uint32_t> px(Renderer::W * Renderer::H);
    float audioCarry = 0;
    auto frame = [&]() {
        g.update(dt);
        g.render();
        g.renderer().resolve(px.data());
        std::fwrite(px.data(), 4, px.size(), frames);
        audioCarry += Audio::RATE * dt;
        int n = int(audioCarry);
        audioCarry -= n;
        std::vector<float> tmp(n * 2);
        g.audio().mix(tmp.data(), n);
        audioBuf.insert(audioBuf.end(), tmp.begin(), tmp.end());
    };
    auto run = [&](float sec, std::function<void()> each = nullptr) {
        for (float t = 0; t < sec; t += dt) { if (each) each(); frame(); }
    };
    run(5.0f);                              // logo
    tapAt(g, 1, 1); run(1.0f);              // skip warning
    tapAt(g, 1, 1); run(3.5f);              // menu
    tapAt(g, 100, 160); run(3.0f);          // new game -> intro
    tapAt(g, 1, 1);
    g.debugStartNight(1);
    run(6.0f);                              // office + SMS
    g.key(Key::Camera, true); run(2.0f);    // check couch
    g.key(Key::Beer, true); run(2.5f);
    g.key(Key::Tv, true); run(1.5f);
    g.debugNegron().debugForce(NegronLoc::Kitchen, 6.0f, false, 0);
    g.key(Key::Cam2, true); run(3.0f);
    g.debugNegron().debugForce(NegronLoc::Corridor, 4.0f, false, 0);
    g.key(Key::Cam3, true); run(3.0f);
    g.key(Key::Camera, true); run(0.3f);
    run(0.8f, [&] { g.key(Key::Left, true); }); g.key(Key::Left, false);
    g.key(Key::Light, true); run(1.0f); g.key(Key::Light, false);
    g.key(Key::Door, true); run(8.0f);      // he bangs, gives up and leaves
    g.key(Key::Door, true); run(0.6f);
    g.key(Key::Light, true); run(0.8f); g.key(Key::Light, false);  // empty doorway
    g.key(Key::Right, true); run(0.5f); g.key(Key::Right, false);
    // rampage!
    g.key(Key::Camera, true); g.key(Key::Cam3, true);
    g.debugNegron().debugForce(NegronLoc::Corridor, 2.5f, true, 0);
    run(2.2f);
    g.key(Key::Camera, true); run(0.3f);
    run(3.0f);                              // too late -> jumpscare
    run(4.0f);
    std::fclose(frames);

    // WAV (16-bit stereo)
    std::ofstream w(dir + "/audio.wav", std::ios::binary);
    auto u32 = [&](uint32_t v) { w.write(reinterpret_cast<char*>(&v), 4); };
    auto u16 = [&](uint16_t v) { w.write(reinterpret_cast<char*>(&v), 2); };
    uint32_t dataBytes = uint32_t(audioBuf.size() * 2);
    w.write("RIFF", 4); u32(36 + dataBytes); w.write("WAVEfmt ", 8);
    u32(16); u16(1); u16(2); u32(Audio::RATE); u32(Audio::RATE * 4); u16(4); u16(16);
    w.write("data", 4); u32(dataBytes);
    for (float s : audioBuf) { int16_t v = int16_t(clampf(s, -1, 1) * 32000); w.write(reinterpret_cast<char*>(&v), 2); }
    std::printf("video frames written: %d x %d @ %d fps\n", Renderer::W, Renderer::H, FPS);
    return 0;
}

// --- app icon / logo art ---
static int icon(const std::string& dir) {
    Renderer r;
    World w;
    w.build(r);
    w.renderLogo(r, 0.6f);
    r.textCentered(Renderer::W / 2, 196, "DED", Vec3(0.85f, 0.06f, 0.05f), 5);
    std::vector<uint32_t> px(Renderer::W * Renderer::H);
    r.resolve(px.data());
    FILE* f = std::fopen((dir + "/icon.ppm").c_str(), "wb");
    std::fprintf(f, "P6\n%d %d\n255\n", Renderer::H, Renderer::H);
    int x0 = (Renderer::W - Renderer::H) / 2;
    for (int y = 0; y < Renderer::H; ++y)
        for (int x = x0; x < x0 + Renderer::H; ++x) {
            uint32_t p = px[y * Renderer::W + x];
            unsigned char c[3] = {uint8_t(p & 0xFF), uint8_t((p >> 8) & 0xFF), uint8_t((p >> 16) & 0xFF)};
            std::fwrite(c, 1, 3, f);
        }
    std::fclose(f);
    // full logo frame too
    w.renderLogo(r, 2.0f);
    int lx = Renderer::W / 2 - r.textWidth("DEAD DED", 4) / 2;
    r.text(lx, 176, "DEAD DED", Vec3(0.8f, 0.05f, 0.04f), 4);
    r.textCentered(Renderer::W / 2, 228, "ENTERTAINMENT", Vec3(0.88f, 0.84f, 0.75f), 2);
    r.resolve(px.data());
    f = std::fopen((dir + "/logo.ppm").c_str(), "wb");
    std::fprintf(f, "P6\n%d %d\n255\n", Renderer::W, Renderer::H);
    for (uint32_t p : px) {
        unsigned char c[3] = {uint8_t(p & 0xFF), uint8_t((p >> 8) & 0xFF), uint8_t((p >> 16) & 0xFF)};
        std::fwrite(c, 1, 3, f);
    }
    std::fclose(f);
    return 0;
}

int main(int argc, char** argv) {
    std::string mode = argc > 1 ? argv[1] : "screens";
    std::string dir = argc > 2 ? argv[2] : ".";
    if (mode == "screens") return screens(dir);
    if (mode == "sim") return sim();
    if (mode == "video") return video(dir);
    if (mode == "icon") return icon(dir);
    std::fprintf(stderr, "usage: %s screens|video|sim [dir]\n", argv[0]);
    return 1;
}
