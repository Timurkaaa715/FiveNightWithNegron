// SDL2 platform layer: Android, iOS (and desktop Linux/macOS/Windows for development).
// The game renders into a 480x270 software framebuffer which is streamed to a
// GPU texture and scaled up with nearest filtering (crunchy PS2-era pixels).
#include <SDL.h>
#include <string>
#include <vector>
#include "game/Game.h"

namespace {

Game* gGame = nullptr;

void audioCallback(void* /*user*/, Uint8* stream, int len) {
    float* out = reinterpret_cast<float*>(stream);
    int frames = len / int(sizeof(float) * 2);
    if (gGame) gGame->audio().mix(out, frames);
    else SDL_memset(stream, 0, len);
}

// Converts window pixel coordinates to framebuffer coordinates (handles letterboxing).
struct Mapper {
    int outW = 1, outH = 1;
    float scale = 1, offX = 0, offY = 0;
    void update(SDL_Renderer* ren) {
        SDL_GetRendererOutputSize(ren, &outW, &outH);
        scale = std::min(float(outW) / Renderer::W, float(outH) / Renderer::H);
        offX = (outW - Renderer::W * scale) * 0.5f;
        offY = (outH - Renderer::H * scale) * 0.5f;
    }
    SDL_Rect dst() const {
        return SDL_Rect{int(offX), int(offY), int(Renderer::W * scale), int(Renderer::H * scale)};
    }
    void fromPixels(float px, float py, float& x, float& y) const {
        x = (px - offX) / scale;
        y = (py - offY) / scale;
    }
};

bool mapKey(SDL_Keycode k, Key& out) {
    switch (k) {
    case SDLK_LEFT: case SDLK_a: out = Key::Left; return true;
    case SDLK_RIGHT: out = Key::Right; return true;
    case SDLK_d: out = Key::Door; return true;
    case SDLK_f: out = Key::Light; return true;
    case SDLK_SPACE: case SDLK_s: out = Key::Camera; return true;
    case SDLK_b: out = Key::Beer; return true;
    case SDLK_t: out = Key::Tv; return true;
    case SDLK_1: out = Key::Cam1; return true;
    case SDLK_2: out = Key::Cam2; return true;
    case SDLK_3: out = Key::Cam3; return true;
    case SDLK_RETURN: out = Key::Enter; return true;
    case SDLK_ESCAPE: case SDLK_AC_BACK: out = Key::Back; return true;
    default: return false;
    }
}

}  // namespace

int main(int argc, char* argv[]) {
    (void)argc; (void)argv;
    SDL_SetHint(SDL_HINT_ORIENTATIONS, "LandscapeLeft LandscapeRight");
    SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, "0");       // nearest: keep pixels sharp
    SDL_SetHint(SDL_HINT_TOUCH_MOUSE_EVENTS, "0");         // we handle touches ourselves
    SDL_SetHint(SDL_HINT_MOUSE_TOUCH_EVENTS, "0");
    SDL_SetHint(SDL_HINT_ANDROID_TRAP_BACK_BUTTON, "1");
    SDL_SetHint(SDL_HINT_IOS_HIDE_HOME_INDICATOR, "2");

    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO | SDL_INIT_EVENTS) != 0) {
        SDL_Log("SDL_Init failed: %s", SDL_GetError());
        return 1;
    }

#if defined(__ANDROID__) || defined(__IPHONEOS__)
    Uint32 winFlags = SDL_WINDOW_FULLSCREEN | SDL_WINDOW_ALLOW_HIGHDPI | SDL_WINDOW_BORDERLESS;
    int winW = 0, winH = 0;
#else
    Uint32 winFlags = SDL_WINDOW_RESIZABLE | SDL_WINDOW_ALLOW_HIGHDPI;
    int winW = Renderer::W * 3, winH = Renderer::H * 3;
#endif
    SDL_Window* win = SDL_CreateWindow("5 Nights in Ded", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, winW, winH, winFlags);
    if (!win) { SDL_Log("SDL_CreateWindow failed: %s", SDL_GetError()); return 1; }
    SDL_Renderer* ren = SDL_CreateRenderer(win, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
    if (!ren) ren = SDL_CreateRenderer(win, -1, SDL_RENDERER_SOFTWARE);
    SDL_Texture* tex = SDL_CreateTexture(ren, SDL_PIXELFORMAT_ABGR8888, SDL_TEXTUREACCESS_STREAMING, Renderer::W, Renderer::H);
    SDL_DisableScreenSaver();

    std::string savePath;
    if (char* pref = SDL_GetPrefPath("DeadDed", "FiveNightsInDed")) {
        savePath = std::string(pref) + "save.txt";
        SDL_free(pref);
    }

    static Game game;  // large framebuffers: keep off the stack
    game.init(savePath);
    gGame = &game;

    SDL_AudioSpec want{}, have{};
    want.freq = Audio::RATE;
    want.format = AUDIO_F32SYS;
    want.channels = 2;
    want.samples = 1024;
    want.callback = audioCallback;
    SDL_AudioDeviceID dev = SDL_OpenAudioDevice(nullptr, 0, &want, &have, 0);
    if (dev == 0) SDL_Log("No audio: %s", SDL_GetError());
    else SDL_PauseAudioDevice(dev, 0);

    Mapper map;
    std::vector<uint32_t> pixels(Renderer::W * Renderer::H);
    Uint64 prev = SDL_GetPerformanceCounter();
    const double freq = double(SDL_GetPerformanceFrequency());
    bool running = true, background = false;

    while (running) {
        map.update(ren);
        SDL_Event e;
        while (SDL_PollEvent(&e)) {
            switch (e.type) {
            case SDL_QUIT: running = false; break;
            case SDL_APP_WILLENTERBACKGROUND:
                game.onPause();
                background = true;
                if (dev) SDL_PauseAudioDevice(dev, 1);
                break;
            case SDL_APP_DIDENTERFOREGROUND:
                background = false;
                if (dev) SDL_PauseAudioDevice(dev, 0);
                prev = SDL_GetPerformanceCounter();
                break;
            case SDL_FINGERDOWN:
            case SDL_FINGERMOTION:
            case SDL_FINGERUP: {
                float x, y;
                map.fromPixels(e.tfinger.x * map.outW, e.tfinger.y * map.outH, x, y);
                int id = int(e.tfinger.fingerId & 0x7FFFFFFF);
                if (e.type == SDL_FINGERDOWN) game.pointerDown(x, y, id);
                else if (e.type == SDL_FINGERMOTION) game.pointerMove(x, y, id);
                else game.pointerUp(x, y, id);
                break;
            }
            case SDL_MOUSEBUTTONDOWN:
            case SDL_MOUSEBUTTONUP:
            case SDL_MOUSEMOTION: {
                // mouse coordinates are in window points; convert to output pixels first (HiDPI)
                int ww, wh;
                SDL_GetWindowSize(win, &ww, &wh);
                float sx = float(map.outW) / std::max(1, ww), sy = float(map.outH) / std::max(1, wh);
                int mx = e.type == SDL_MOUSEMOTION ? e.motion.x : e.button.x;
                int my = e.type == SDL_MOUSEMOTION ? e.motion.y : e.button.y;
                float x, y;
                map.fromPixels(mx * sx, my * sy, x, y);
                const int MOUSE_ID = 1 << 30;
                if (e.type == SDL_MOUSEBUTTONDOWN) game.pointerDown(x, y, MOUSE_ID);
                else if (e.type == SDL_MOUSEBUTTONUP) game.pointerUp(x, y, MOUSE_ID);
                else if (e.motion.state & SDL_BUTTON_LMASK) game.pointerMove(x, y, MOUSE_ID);
                break;
            }
            case SDL_KEYDOWN:
            case SDL_KEYUP: {
                if (e.key.repeat) break;
                Key k;
                if (mapKey(e.key.keysym.sym, k)) game.key(k, e.type == SDL_KEYDOWN);
                break;
            }
            default: break;
            }
        }
        if (game.wantsQuit()) running = false;

        Uint64 now = SDL_GetPerformanceCounter();
        float dt = float((now - prev) / freq);
        prev = now;
        if (background) { SDL_Delay(50); continue; }

        game.update(dt);
        game.render();
        game.renderer().resolve(pixels.data());
        SDL_UpdateTexture(tex, nullptr, pixels.data(), Renderer::W * 4);
        SDL_SetRenderDrawColor(ren, 0, 0, 0, 255);
        SDL_RenderClear(ren);
        SDL_Rect dst = map.dst();
        SDL_RenderCopy(ren, tex, nullptr, &dst);
        SDL_RenderPresent(ren);
    }

    gGame = nullptr;
    if (dev) SDL_CloseAudioDevice(dev);
    SDL_DestroyTexture(tex);
    SDL_DestroyRenderer(ren);
    SDL_DestroyWindow(win);
    SDL_Quit();
    return 0;
}
