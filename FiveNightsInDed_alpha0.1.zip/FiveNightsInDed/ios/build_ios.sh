#!/usr/bin/env bash
# Generates an Xcode project for iPhone/iPad. Needs macOS + Xcode 14+, CMake 3.20+, git.
set -euo pipefail
cd "$(dirname "$0")"
SDL_TAG="release-2.30.9"
[ -d SDL ] || git clone --depth 1 --branch "$SDL_TAG" https://github.com/libsdl-org/SDL.git SDL
cmake -S . -B build -G Xcode \
  -DCMAKE_SYSTEM_NAME=iOS \
  -DCMAKE_OSX_DEPLOYMENT_TARGET=13.0 \
  -DCMAKE_OSX_ARCHITECTURES=arm64
echo
echo "Open ios/build/fnad_ios.xcodeproj, pick the 'fnad' target,"
echo "set your Team in Signing & Capabilities and press Run on your iPhone."
